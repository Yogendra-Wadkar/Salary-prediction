import json
import time
from typing import Any, Dict, List

import pandas as pd
from langchain_core.documents import Document
from pydantic import BaseModel, Field

from rag.retriever import retrieve_documents
from rag.embeddings import get_embedding_model
from rag.vector_store import get_vector_store
from rag.rag_pipeline import (
    get_llm,
    get_structured_llm,
)

from prompts.curriculum_prompts import (
    create_curriculum_generation_prompt,
    build_curriculum_generation_inputs,
)

from prompts.optimizer_prompts import (
    create_optimizer_prompt,
    build_optimizer_inputs,
)

from prompts.assessment_prompts import (
    create_assessment_prompt,
    build_assessment_inputs,
    REPLACEMENT_QUESTION_PROMPT,
    REPLACEMENT_QUESTION_HUMAN_TEMPLATE,
)

from rag.indexer import index_document


# ============================================================
# MODEL CONFIGURATION
# ============================================================

# Fast model for simple syllabus extraction.
STAGE_A_MODEL = "gemini-3.5-flash-lite"

# Stronger model for curriculum planning.
STAGE_B_MODEL = "gemini-3.7-flash"


# ============================================================
# GENERAL CONFIGURATION
# ============================================================

# Stage A only needs:
# Unit -> Chapter -> Topic -> Subtopic
#
# We do not need answer/explanation chunks here.
STAGE_A_CONTENT_TYPES = (
    "theory",
    "toc",
)

# Keep the batch size at 75,000.
#
# We are no longer depending on a smaller batch to fix JSON.
# Stage A now uses native structured output.
STAGE_A_CHAR_BUDGET = 75_000

# Only one retry for temporary Gemini server errors.
MAX_RETRIES = 1
RETRY_BACKOFF_SECONDS = 3


# ============================================================
# STAGE-A STRUCTURED OUTPUT
# ============================================================

class StageATopic(BaseModel):
    topic: str = Field(
        description="A topic explicitly present in the syllabus."
    )

    subtopics: List[str] = Field(
        default_factory=list,
        description="Subtopics explicitly associated with the topic."
    )


class StageAUnit(BaseModel):
    unit: str = Field(
        description="The unit name or identifier from the syllabus."
    )

    chapter: str = Field(
    description=(
        "The complete chapter label and chapter name exactly as written "
        "in the syllabus, including numbering. Example: "
        "'Chapter 1: Linear Equations in Two Variables'."
    )
)

    topics: List[StageATopic] = Field(
        default_factory=list,
        description="Topics belonging to the chapter."
    )


class StageAExtraction(BaseModel):
    units: List[StageAUnit] = Field(
        default_factory=list,
        description=(
            "Syllabus hierarchy containing units, chapters, "
            "topics and subtopics."
        ),
    )


# ============================================================
# STAGE-B STRUCTURED OUTPUT
# ============================================================

class CurriculumWeek(BaseModel):
    year: str
    month: str
    week: str
    unit: str
    topic: str
    planned_content: str
    suggested_activities: str
    assessment_or_revision: str
    status: str


class CurriculumOutput(BaseModel):
    curriculum: List[CurriculumWeek] = Field(
        default_factory=list
    )

    unscheduled_or_flagged_items: List[str] = Field(
        default_factory=list
    )

    notes: str = ""


# ============================================================
# CHROMADB FILTER
# ============================================================

def _build_metadata_filter(
    subject: str,
    grade: str,
    academic_year: str,
    curriculum_id: str = None,
) -> dict:
    """
    Build the ChromaDB filter for the selected syllabus.
    """

    conditions = [
        {"subject": subject},
        {"grade": grade},
        {"academic_year": academic_year},
        {"content_type": {"$in": list(STAGE_A_CONTENT_TYPES)}},
    ]
    
    if curriculum_id is not None:
        conditions.append({"curriculum_id": str(curriculum_id)})

    return {
        "$and": conditions
    }


# ============================================================
# LOAD SYLLABUS FROM CHROMADB
# ============================================================

def _get_syllabus_chunks(
    subject: str,
    grade: str,
    academic_year: str,
    curriculum_id: str = None,
) -> List[Document]:
    """
    Load syllabus chunks for the selected
    subject, grade and academic year.
    """

    embeddings = get_embedding_model()

    vector_store = get_vector_store(
        embeddings=embeddings
    )

    result = vector_store.get(
        where=_build_metadata_filter(
            subject=subject,
            grade=grade,
            academic_year=academic_year,
            curriculum_id=curriculum_id,
        ),
        include=[
            "documents",
            "metadatas",
        ],
    )

    documents = []

    raw_documents = (
        result.get(
            "documents",
            []
        )
        or []
    )

    raw_metadatas = (
        result.get(
            "metadatas",
            []
        )
        or []
    )

    for text, metadata in zip(
        raw_documents,
        raw_metadatas,
    ):
        if not text:
            continue

        documents.append(
            Document(
                page_content=text.strip(),
                metadata=metadata or {},
            )
        )

    documents.sort(
        key=lambda document: (
            int(
                document.metadata.get(
                    "page",
                    0,
                )
                or 0
            ),
            int(
                document.metadata.get(
                    "chunk_id",
                    0,
                )
                or 0
            ),
        )
    )

    return documents


# ============================================================
# REMOVE EXACT DUPLICATES
# ============================================================

def _remove_exact_duplicates(
    documents: List[Document],
) -> List[Document]:
    """
    Remove only exact duplicate chunks.
    """

    seen = set()
    cleaned = []

    for document in documents:
        text = document.page_content.strip()

        if not text:
            continue

        if text in seen:
            continue

        seen.add(text)

        cleaned.append(
            Document(
                page_content=text,
                metadata=document.metadata,
            )
        )

    return cleaned


# ============================================================
# FORMAT CHUNKS
# ============================================================

def _format_chunk(
    document: Document,
) -> str:
    """
    Format a single chunk for Gemini.
    """

    page = document.metadata.get(
        "page",
        "unknown",
    )

    return (
        f"[Page {page}]\n"
        f"{document.page_content}"
    )


def _format_chunks(
    documents: List[Document],
) -> str:
    """
    Convert multiple chunks into one string.
    """

    return "\n\n".join(
        _format_chunk(document)
        for document in documents
    )


# ============================================================
# CREATE STAGE-A BATCHES
# ============================================================

def _create_budget_batches(
    documents: List[Document],
) -> List[List[Document]]:
    """
    Create macro-batches using the configured
    character budget.
    """

    if not documents:
        return []

    batches = []

    current_batch = []
    current_size = 0

    for document in documents:

        formatted_size = len(
            _format_chunk(document)
        )

        if (
            current_batch
            and current_size
            + formatted_size
            > STAGE_A_CHAR_BUDGET
        ):
            batches.append(
                current_batch
            )

            current_batch = []
            current_size = 0

        current_batch.append(
            document
        )

        current_size += formatted_size

    if current_batch:
        batches.append(
            current_batch
        )

    return batches


# ============================================================
# GEMINI RETRY HANDLING
# ============================================================

def _is_transient_error(
    error: Exception,
) -> bool:
    """
    Return True only for temporary Gemini
    server errors.
    """

    message = str(error).upper()

    return any(
        marker in message
        for marker in (
            "503",
            "UNAVAILABLE",
            "OVERLOADED",
        )
    )


def _invoke_with_retry(
    llm,
    messages,
):
    """
    Invoke Gemini.

    503 errors receive one retry.
    429 quota errors are NOT retried.
    """

    last_error: Exception = RuntimeError(
        "Unexpected: no attempts were made"
    )

    for attempt in range(
        MAX_RETRIES + 1
    ):
        try:
            return llm.invoke(
                messages
            )

        except Exception as error:
            last_error = error

            # Do not retry quota errors.
            if (
                not _is_transient_error(
                    error
                )
                or attempt == MAX_RETRIES
            ):
                raise

            time.sleep(
                RETRY_BACKOFF_SECONDS
                * (
                    attempt + 1
                )
            )

    raise last_error


# ============================================================
# CONVERT STRUCTURED RESULT
# ============================================================

def _model_to_dict(
    result: Any,
) -> Dict[str, Any]:
    """
    Convert Pydantic model or dict into
    a normal Python dictionary.
    """

    if isinstance(
        result,
        dict,
    ):
        return result

    if hasattr(
        result,
        "model_dump",
    ):
        return result.model_dump()

    if hasattr(
        result,
        "dict",
    ):
        return result.dict()

    raise ValueError(
        "Unexpected structured Gemini response type: "
        f"{type(result)}"
    )


# ============================================================
# STAGE-A PROMPT
# ============================================================

def _create_stage_a_prompt(
    subject: str,
    grade: str,
    academic_year: str,
    batch_number: int,
    total_batches: int,
    syllabus_text: str,
) -> str:
    """
    Create the compact Stage-A extraction prompt.

    Only the hierarchy required for curriculum
    generation is extracted.
    """

    return f"""
You are extracting the syllabus structure for an
educational curriculum planning system.

Subject: {subject}
Grade: {grade}
Academic Year: {academic_year}

This is Stage A of a curriculum-generation pipeline.

Batch {batch_number} of {total_batches}.

Extract ONLY the following syllabus hierarchy:

1. Unit
2. Chapter
3. Topic
4. Subtopic

Rules:

- Use only information explicitly present in the syllabus.
- Do not invent topics.
- Do not invent subtopics.
- Preserve syllabus wording whenever possible.
- Do not generate a curriculum.
- Do not generate teaching plans.
- Do not generate activities.
- Do not generate important concepts.
- Do not generate explanations.
- Do not generate source pages.
- Do not generate answer keys.
- Do not generate exercise solutions.
- Do not summarize unrelated information.
- Keep topics under the correct chapter.
- Keep subtopics under the correct topic.
- If a topic has no clear subtopics, return an empty list.
- Preserve the original syllabus hierarchy.
- Preserve chapter numbering exactly as written in the syllabus.
- If the syllabus says "Chapter 1: Linear Equations in Two Variables",
  return the chapter value exactly as "Chapter 1: Linear Equations in Two Variables".
- Never return only the chapter name without its number.
- Never remove, change, or renumber chapter labels.
- If no Unit exists in the syllabus, keep the unit field empty.

Return only the structured output required by the schema.

SYLLABUS CONTENT:

{syllabus_text}
"""


# ============================================================
# STAGE A EXTRACTION
# ============================================================

def _extract_batch(
    subject: str,
    grade: str,
    academic_year: str,
    batch_number: int,
    total_batches: int,
    documents: List[Document],
) -> Dict[str, Any]:
    """
    Extract a compact structured syllabus
    from one Stage-A batch.

    IMPORTANT:
    Stage A uses the FAST model.
    """

    structured_llm = get_structured_llm(
        schema=StageAExtraction,
        model=STAGE_A_MODEL,
        max_output_tokens=4096,
        thinking_level="minimal",
        api_key_env="GOOGLE_API_KEY_CURRICULUM",
    )

    syllabus_text = _format_chunks(
        documents
    )

    prompt = _create_stage_a_prompt(
        subject=subject,
        grade=grade,
        academic_year=academic_year,
        batch_number=batch_number,
        total_batches=total_batches,
        syllabus_text=syllabus_text,
    )

    result = _invoke_with_retry(
        llm=structured_llm,
        messages=prompt,
    )

    return _model_to_dict(
        result
    )


# ============================================================
# COMBINE STAGE-A RESULTS
# ============================================================

def _combine_batches(
    results: List[Dict[str, Any]],
) -> str:
    """
    Combine all Stage-A results into one
    compact syllabus structure.
    """

    units = []

    seen_topics = set()

    for result in results:

        for unit in result.get(
            "units",
            [],
        ):

            unit_name = str(
                unit.get(
                    "unit",
                    "",
                )
            ).strip()

            chapter_name = str(
                unit.get(
                    "chapter",
                    "",
                )
            ).strip()

            if (
                not unit_name
                and not chapter_name
            ):
                continue

            existing_unit = next(
                (
                    item
                    for item in units
                    if (
                        item.get(
                            "unit"
                        )
                        == unit_name
                        and item.get(
                            "chapter"
                        )
                        == chapter_name
                    )
                ),
                None,
            )

            if existing_unit is None:

                existing_unit = {
                    "unit": unit_name,
                    "chapter": chapter_name,
                    "topics": [],
                }

                units.append(
                    existing_unit
                )

            for topic in unit.get(
                "topics",
                [],
            ):

                topic_name = str(
                    topic.get(
                        "topic",
                        "",
                    )
                ).strip()

                if not topic_name:
                    continue

                topic_key = (
                    unit_name,
                    chapter_name,
                    topic_name,
                )

                if topic_key in seen_topics:
                    continue

                seen_topics.add(
                    topic_key
                )

                subtopics = []

                for subtopic in topic.get(
                    "subtopics",
                    [],
                ):

                    value = str(
                        subtopic
                    ).strip()

                    if (
                        value
                        and value
                        not in subtopics
                    ):
                        subtopics.append(
                            value
                        )

                existing_unit[
                    "topics"
                ].append(
                    {
                        "topic": topic_name,
                        "subtopics": subtopics,
                    }
                )

    combined = {
        "units": units
    }

    return json.dumps(
        combined,
        ensure_ascii=False,
        indent=2,
    )


# ============================================================
# STAGE-B FINAL CURRICULUM
# ============================================================

def _generate_final_curriculum(
    teacher_name: str,
    subject: str,
    grade: str,
    academic_year: str,
    start_month: str,
    end_month: str,
    total_teaching_days: str,
    weekly_teaching_hours: str,
    assessment_frequency: str,
    midterm_exam_month: str,
    final_exam_month: str,
    structured_syllabus: str,
) -> Dict[str, Any]:
    """
    Generate the final weekly curriculum.

    IMPORTANT:
    Stage B uses the stronger model.
    """

    structured_llm = get_structured_llm(
        schema=CurriculumOutput,
        model=STAGE_B_MODEL,
        max_output_tokens=16384,
        thinking_level="low",
        api_key_env="GOOGLE_API_KEY_CURRICULUM",
    )

    prompt = create_curriculum_generation_prompt()

    inputs = build_curriculum_generation_inputs(
        teacher_name=teacher_name,
        subject=subject,
        grade=grade,
        academic_year=academic_year,
        start_month=start_month,
        end_month=end_month,
        total_teaching_days=total_teaching_days,
        weekly_teaching_hours=weekly_teaching_hours,
        assessment_frequency=assessment_frequency,
        midterm_exam_month=midterm_exam_month,
        final_exam_month=final_exam_month,
        structured_syllabus=structured_syllabus,
    )

    messages = prompt.format_messages(
        **inputs
    )

    result = _invoke_with_retry(
        llm=structured_llm,
        messages=messages,
    )

    return _model_to_dict(
        result
    )


# ============================================================
# KEEP GENERATED CURRICULUM IN SYLLABUS ORDER
# ============================================================

def _repair_curriculum_order(
    curriculum: Dict[str, Any],
    structured_syllabus: str,
) -> Dict[str, Any]:
    """Keep normal teaching rows in the syllabus chapter/topic order."""

    rows = list(curriculum.get("curriculum", []))

    try:
        syllabus = json.loads(structured_syllabus)
    except (TypeError, json.JSONDecodeError):
        return curriculum

    chapter_order = []
    topic_order = {}

    for item in syllabus.get("units", []):
        chapter = str(item.get("chapter", "")).strip()
        if not chapter:
            chapter = str(item.get("unit", "")).strip()
        if not chapter:
            continue

        chapter_key = " ".join(
            chapter.lower().replace(":", " ").split()
        )

        if chapter_key not in topic_order:
            chapter_order.append(chapter_key)
            topic_order[chapter_key] = {}

        for topic in item.get("topics", []):
            name = str(topic.get("topic", "")).strip()
            key = " ".join(
                name.lower().replace(":", " ").split()
            )
            if key and key not in topic_order[chapter_key]:
                topic_order[chapter_key][key] = len(
                    topic_order[chapter_key]
                )

    if not chapter_order:
        return curriculum

    def special(row: Dict[str, Any]) -> bool:
        unit = str(row.get("unit", "")).strip().lower()
        assessment = str(
            row.get("assessment_or_revision", "")
        ).strip().lower()

        labels = (
            "midterm revision",
            "midterm examination",
            "midterm break",
            "final revision",
            "final examination",
            "post-exam break",
        )

        return any(unit.startswith(label) for label in labels) or assessment in {
            "midterm revision",
            "midterm examination",
            "final revision",
        }

    def key(row: Dict[str, Any]):
        unit = " ".join(
            str(row.get("unit", ""))
            .lower()
            .replace(":", " ")
            .split()
        )
        topic = " ".join(
            str(row.get("topic", ""))
            .lower()
            .replace(":", " ")
            .split()
        )

        chapter_index = len(chapter_order)
        matched = None

        for index, chapter in enumerate(chapter_order):
            if unit == chapter or unit.startswith(chapter):
                chapter_index = index
                matched = chapter
                break

        if matched is None:
            for index, chapter in enumerate(chapter_order):
                if chapter in unit or unit in chapter:
                    chapter_index = index
                    matched = chapter
                    break

        topic_index = topic_order.get(matched, {}).get(
            topic,
            len(topic_order.get(matched, {})),
        )

        return chapter_index, topic_index

    positions = [
        i for i, row in enumerate(rows)
        if not special(row)
    ]

    teaching_rows = sorted(
        (rows[i] for i in positions),
        key=key,
    )

    for position, teaching_row in zip(positions, teaching_rows):
        calendar = rows[position]
        repaired_row = dict(teaching_row)
        repaired_row["year"] = calendar.get("year", "")
        repaired_row["month"] = calendar.get("month", "")
        repaired_row["week"] = calendar.get("week", "")
        rows[position] = repaired_row

    curriculum["curriculum"] = rows
    return curriculum


# ============================================================
# PUBLIC CURRICULUM WORKFLOW
# ============================================================

def generate_curriculum(
    teacher_name: str,
    subject: str,
    grade: str,
    academic_year: str,
    start_month: str,
    end_month: str,
    total_teaching_days: str,
    weekly_teaching_hours: str,
    assessment_frequency: str,
    midterm_month: str,
    final_month: str,
    curriculum_id: str = None,
) -> Dict[str, Any]:
    """
    Complete curriculum-generation workflow.

    Stage A:
        ChromaDB
        -> cleanup
        -> 75k batches
        -> Gemini 3.5 Flash-Lite
        -> compact syllabus hierarchy

    Stage B:
        compact syllabus hierarchy
        -> Gemini 3.6 Flash
        -> weekly curriculum
    """

    # --------------------------------------------------------
    # Stage A
    # --------------------------------------------------------

    documents = _get_syllabus_chunks(
        subject=subject,
        grade=grade,
        academic_year=academic_year,
        curriculum_id=curriculum_id,
    )

    if not documents:
        raise ValueError(
            "No indexed syllabus found for the selected "
            "subject, grade, and academic year."
        )

    documents = _remove_exact_duplicates(
        documents
    )

    batches = _create_budget_batches(
        documents
    )

    if not batches:
        raise ValueError(
            "No usable syllabus content was found."
        )

    print(
        "=================================================="
    )

    print(
        "STAGE A"
    )

    print(
        f"Model: {STAGE_A_MODEL}"
    )

    print(
        f"Thinking: minimal"
    )

    print(
        f"Chunks: {len(documents)}"
    )

    print(
        f"Batches: {len(batches)}"
    )

    print(
        "=================================================="
    )

    batch_results = []

    for batch_number, batch in enumerate(
        batches,
        start=1,
    ):

        print(
            f"Stage A: processing batch "
            f"{batch_number}/{len(batches)}..."
        )

        result = _extract_batch(
            subject=subject,
            grade=grade,
            academic_year=academic_year,
            batch_number=batch_number,
            total_batches=len(batches),
            documents=batch,
        )

        batch_results.append(
            result
        )

    structured_syllabus = _combine_batches(
        results=batch_results
    )
    with open("stage_a_debug.json", "w", encoding="utf-8") as f:
        f.write(structured_syllabus)

    print(structured_syllabus)
    print(f"Stage A combined syllabus size: {len(structured_syllabus):,} characters")
    # --------------------------------------------------------
    # Stage B
    # --------------------------------------------------------

    print(
        "=================================================="
    )

    print(
        "STAGE B"
    )

    print(
        f"Model: {STAGE_B_MODEL}"
    )

    print(
        f"Thinking: low"
    )

    print(
        "Generating final curriculum..."
    )

    print(
        "=================================================="
    )

    curriculum = _generate_final_curriculum(
        teacher_name=teacher_name,
        subject=subject,
        grade=grade,
        academic_year=academic_year,
        start_month=start_month,
        end_month=end_month,
        total_teaching_days=total_teaching_days,
        weekly_teaching_hours=weekly_teaching_hours,
        assessment_frequency=assessment_frequency,
        midterm_exam_month=midterm_month,
        final_exam_month=final_month,
        structured_syllabus=structured_syllabus,
    )

    curriculum = _repair_curriculum_order(
        curriculum=curriculum,
        structured_syllabus=structured_syllabus,
    )

    print(
        "Curriculum generation completed."
    )

    return curriculum


# ============================================================
# EXISTING CURRICULUM LOADER
# ============================================================

def _load_existing_curriculum(
    file_path: str,
) -> str:
    """
    Load an existing curriculum from
    PDF, DOCX or XLSX.
    """

    path = str(
        file_path
    )

    if path.lower().endswith(
        ".xlsx"
    ):

        workbook = pd.ExcelFile(
            path
        )

        parts = []

        for sheet in workbook.sheet_names:

            dataframe = pd.read_excel(
                path,
                sheet_name=sheet,
            )

            parts.append(
                f"Sheet: {sheet}\n"
                f"{dataframe.to_csv(index=False)}"
            )

        return "\n\n".join(
            parts
        )

    if (
        path.lower().endswith(
            ".pdf"
        )
        or path.lower().endswith(
            ".docx"
        )
    ):

        from utils.document_utils import (
            load_document
        )

        documents = load_document(
            path
        )

        return "\n\n".join(
            document.page_content
            for document in documents
        )

    raise ValueError(
        "Unsupported curriculum file type. "
        "Use PDF, DOCX or XLSX."
    )


# ============================================================
# CURRICULUM OPTIMIZER
# ============================================================

def analyze_and_improve(
    form_data: Dict[str, Any],
    existing_plan_path: str,
    syllabus_path: str,
    curriculum_id: str = None,
) -> Dict[str, Any]:
    """
    Analyze an existing curriculum against
    the syllabus and generate an improved plan.

    This workflow remains on the default
    Gemini 3.6 model.
    """

    index_document(
        file_path=syllabus_path,
        metadata={
            "teacher_name": form_data.get(
                "teacher_name",
                "",
            ),
            "subject": form_data.get(
                "subject",
                "",
            ),
            "grade": form_data.get(
                "grade",
                "",
            ),
            "academic_year": form_data.get(
                "academic_year",
                "",
            ),
            "document_type": "syllabus",
            "curriculum_id": str(curriculum_id) if curriculum_id is not None else "",
        },
    )

    syllabus_documents = _get_syllabus_chunks(
        subject=form_data[
            "subject"
        ],
        grade=form_data[
            "grade"
        ],
        academic_year=form_data[
            "academic_year"
        ],
        curriculum_id=curriculum_id,
    )

    if not syllabus_documents:
        raise ValueError(
            "No indexed syllabus content found "
            "for curriculum optimization."
        )

    syllabus_context = _format_chunks(
        syllabus_documents
    )

    existing_curriculum = (
        _load_existing_curriculum(
            existing_plan_path
        )
    )

    llm = get_llm(
        model=STAGE_B_MODEL,
        max_output_tokens=16384,
        thinking_level="low",
        api_key_env="GOOGLE_API_KEY_CURRICULUM",
    )

    prompt = create_optimizer_prompt()

    inputs = build_optimizer_inputs(
        teacher_name=form_data.get(
            "teacher_name",
            "",
        ),
        subject=form_data.get(
            "subject",
            "",
        ),
        grade=form_data.get(
            "grade",
            "",
        ),
        academic_year=form_data.get(
            "academic_year",
            "",
        ),
        start_month=form_data.get(
            "start_month",
            "",
        ),
        end_month=form_data.get(
            "end_month",
            "",
        ),
        total_teaching_days=form_data.get(
            "total_teaching_days",
            "",
        ),
        weekly_teaching_hours=form_data.get(
            "weekly_teaching_hours",
            "",
        ),
        assessment_frequency=form_data.get(
            "assessment_frequency",
            "",
        ),
        midterm_exam_month=form_data.get(
            "midterm_exam_month",
            "",
        ),
        final_exam_month=form_data.get(
            "final_exam_month",
            "",
        ),
        syllabus_context=syllabus_context,
        existing_curriculum=existing_curriculum,
    )

    messages = prompt.format_messages(
        **inputs
    )

    response = _invoke_with_retry(
        llm=llm,
        messages=messages,
    )

    content = response.content

    if isinstance(
        content,
        list,
    ):
        parts = []

        for item in content:

            if isinstance(
                item,
                str,
            ):
                parts.append(
                    item
                )

            elif isinstance(
                item,
                dict,
            ):
                if item.get(
                    "type"
                ) == "text":
                    value = item.get(
                        "text",
                        "",
                    )

                    if value:
                        parts.append(
                            value
                        )

        content = "\n".join(
            parts
        )

    content = str(
        content
    ).strip()

    if content.startswith(
        "```"
    ):
        content = content.replace(
            "```json",
            "",
            1,
        )
        content = content.replace(
            "```",
            "",
            1,
        )
        content = content.strip()

    try:
        result = json.loads(
            content
        )

    except json.JSONDecodeError as error:
        raise ValueError(
            "Gemini returned invalid optimizer JSON."
        ) from error

    return {
        "alignment_review": result.get(
            "alignment_review",
            {},
        ),
        "improved_curriculum": {
            "curriculum": result.get(
                "improved_curriculum",
                [],
            ),
            "unscheduled_or_flagged_items": result.get(
                "unscheduled_or_flagged_items",
                [],
            ),
            "notes": result.get(
                "notes",
                "",
            ),
        },
    }


# ============================================================
# ASSESSMENT STRUCTURED OUTPUT SCHEMAS
# ============================================================

class AssessmentQuestion(BaseModel):
    id: int
    type: str
    difficulty: str
    question: str
    options: List[str] = Field(default_factory=list)
    answer: str
    explanation: str

class AssessmentGenerationOutput(BaseModel):
    title: str
    description: str
    questions: List[AssessmentQuestion]

class ReplacementQuestionOutput(BaseModel):
    type: str
    difficulty: str
    question: str
    options: List[str] = Field(default_factory=list)
    answer: str
    explanation: str

# ============================================================
# REPLACEMENT QUESTION GENERATION
# ============================================================

def generate_replacement_question(
    subject: str,
    grade: str,
    academic_year: str,
    assessment_period: str,
    question_type: str,
    difficulty: str,
    question: str,
    curriculum_id: str = None,
) -> Dict[str, Any]:

    embeddings = get_embedding_model()

    vector_store = get_vector_store(
        embeddings=embeddings
    )

    documents = retrieve_documents(
        vector_store=vector_store,
        query=question,
        k=8,
        subject=subject,
        grade=grade,
        academic_year=academic_year,
        curriculum_id=curriculum_id,
        content_types=None,
    )

    context = _format_chunks(documents)

    messages = [
        (
            "system",
            REPLACEMENT_QUESTION_PROMPT,
        ),
        (
            "human",
            REPLACEMENT_QUESTION_HUMAN_TEMPLATE.format(
                subject=subject,
                grade=grade,
                assessment_period=assessment_period,
                question_type=question_type,
                difficulty=difficulty,
                question=question,
                syllabus_context=context,
            ),
        ),
    ]

    structured_llm = get_structured_llm(
        schema=ReplacementQuestionOutput,
        model=STAGE_B_MODEL,
        max_output_tokens=1024,
        thinking_level="low",
        api_key_env="GOOGLE_API_KEY_LEGACY_ASSESSMENT",
    )

    result = _invoke_with_retry(
        llm=structured_llm,
        messages=messages,
    )

    result_dict = _model_to_dict(result)
    result_dict["question"] = question

    return result_dict


# ============================================================
# ASSESSMENT GENERATION
# ============================================================

def generate_assessment(
    config: Dict[str, Any],
    curriculum_id: str = None,
) -> Dict[str, Any]:
    """
    Generate assessment questions using
    syllabus context.

    This workflow uses the stronger Stage-B model
    because assessment generation requires more
    detailed generation than Stage A extraction.
    """

    subject = config.get(
        "subject",
        "",
    )

    grade = config.get(
        "grade",
        "",
    )

    academic_year = config.get(
        "academic_year",
        "",
    )

    assessment_type = config.get(
        "assessment_type",
        "Regular",
    )

    syllabus_documents = _get_syllabus_chunks(
        subject=subject,
        grade=grade,
        academic_year=academic_year,
        curriculum_id=curriculum_id,
    )

    if not syllabus_documents:
        raise ValueError(
            "No indexed syllabus found for assessment generation."
        )

    syllabus_context = _format_chunks(
        syllabus_documents
    )

    structured_llm = get_structured_llm(
        schema=AssessmentGenerationOutput,
        model=STAGE_B_MODEL,
        max_output_tokens=16384,
        thinking_level="low",
        api_key_env="GOOGLE_API_KEY_LEGACY_ASSESSMENT",
    )

    prompt = create_assessment_prompt()

    inputs = build_assessment_inputs(
        assessment_type=assessment_type,
        subject=subject,
        grade=grade,
        assessment_period=config.get(
            "portion",
            "",
        ),
        difficulty_distribution=config.get(
            "difficulty_distribution",
            {},
        ),
        question_type_distribution=config.get(
            "question_type_distribution",
            {},
        ),
        number_of_questions=config.get(
            "num_questions",
            10,
        ),
        syllabus_context=syllabus_context,
    )

    messages = prompt.format_messages(
        **inputs
    )

    result = _invoke_with_retry(
        llm=structured_llm,
        messages=messages,
    )

    return _model_to_dict(result)