"""
TeacherOS Phase 2 — Agent Tools

All tools enforce user_id + curriculum_id ownership.
No arbitrary SQL. No filesystem access. No exposed API keys.
"""

from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc

from backend.models import (
    Curriculum, CurriculumWeek, AgentMemory,
    AssessmentBatch, Assessment,
)
from agents.memory import get_memories, save_memory
from rag.embeddings import get_embedding_model
from rag.vector_store import get_vector_store
from rag.retriever import retrieve_documents, format_retrieved_documents


# ============================================================
# BOUNDED RETRIEVAL
# ============================================================

def _bounded_k(requested_k: int = 4) -> int:
    """Safely bound retrieval k to [1, 8]. Default=4, max=8."""
    return max(1, min(requested_k, 8))


# ============================================================
# OWNERSHIP VERIFICATION
# ============================================================

def verify_curriculum_ownership(
    db: Session, user_id: int, curriculum_id: int
) -> Curriculum:
    """
    Load curriculum and verify it belongs to the authenticated user.
    Raises ValueError if not found or not owned.
    """
    curriculum = (
        db.query(Curriculum)
        .filter(Curriculum.id == curriculum_id, Curriculum.user_id == user_id)
        .first()
    )
    if not curriculum:
        raise ValueError(
            f"Curriculum {curriculum_id} not found or not owned by user {user_id}"
        )
    return curriculum


# ============================================================
# CURRICULUM AGENT TOOLS
# ============================================================

def get_curriculum(db: Session, user_id: int, curriculum_id: int) -> Dict[str, Any]:
    """Load curriculum metadata from PostgreSQL with ownership check."""
    c = verify_curriculum_ownership(db, user_id, curriculum_id)
    return {
        "id": c.id,
        "subject": c.subject,
        "grade": c.grade,
        "academic_year": c.academic_year,
        "teacher_name": c.teacher_name,
        "workflow_type": c.workflow_type,
        "start_month": c.start_month,
        "end_month": c.end_month,
        "total_teaching_days": c.total_teaching_days,
        "weekly_teaching_hours": c.weekly_teaching_hours,
        "assessment_frequency": c.assessment_frequency,
        "midterm_exam_month": c.midterm_exam_month,
        "final_exam_month": c.final_exam_month,
    }


def get_curriculum_weeks(
    db: Session, user_id: int, curriculum_id: int
) -> List[Dict[str, Any]]:
    """Load all curriculum weeks ordered by order_index."""
    verify_curriculum_ownership(db, user_id, curriculum_id)
    weeks = (
        db.query(CurriculumWeek)
        .filter(CurriculumWeek.curriculum_id == curriculum_id)
        .order_by(CurriculumWeek.order_index)
        .all()
    )
    return [
        {
            "id": w.id,
            "order_index": w.order_index,
            "year": w.year,
            "month": w.month,
            "week": w.week,
            "unit": w.unit,
            "topic": w.topic,
            "planned_content": w.planned_content,
            "suggested_activities": w.suggested_activities,
            "assessment_or_revision": w.assessment_or_revision,
            "status": w.status,
        }
        for w in weeks
    ]


def get_curriculum_metadata(
    db: Session, user_id: int, curriculum_id: int
) -> Dict[str, Any]:
    """Return subject, grade, academic_year, and month info."""
    c = verify_curriculum_ownership(db, user_id, curriculum_id)
    return {
        "subject": c.subject,
        "grade": c.grade,
        "academic_year": c.academic_year,
        "start_month": c.start_month,
        "end_month": c.end_month,
        "midterm_exam_month": c.midterm_exam_month,
        "final_exam_month": c.final_exam_month,
    }


def search_syllabus(
    curriculum_id: int,
    query: str,
    k: int = 4,
    content_types: Optional[List[str]] = None,
) -> str:
    """
    Semantic search in Chroma for syllabus content.
    Bounded to k=4 default, max k=8.
    """
    safe_k = _bounded_k(k)
    embeddings = get_embedding_model()
    vs = get_vector_store(embeddings=embeddings)
    docs = retrieve_documents(
        vector_store=vs,
        query=query,
        k=safe_k,
        curriculum_id=curriculum_id,
        content_types=content_types or ["theory"],
    )
    return format_retrieved_documents(docs)


def update_curriculum_week(
    db: Session,
    user_id: int,
    curriculum_id: int,
    week_id: int,
    updates: Dict[str, Any],
) -> Dict[str, Any]:
    """Update a single curriculum week row with ownership check."""
    verify_curriculum_ownership(db, user_id, curriculum_id)
    week = (
        db.query(CurriculumWeek)
        .filter(
            CurriculumWeek.id == week_id,
            CurriculumWeek.curriculum_id == curriculum_id,
        )
        .first()
    )
    if not week:
        raise ValueError(f"Week {week_id} not found in curriculum {curriculum_id}")

    allowed_fields = {
        "year", "month", "week", "unit", "topic",
        "planned_content", "suggested_activities",
        "assessment_or_revision", "status",
    }
    for key, value in updates.items():
        if key in allowed_fields:
            setattr(week, key, str(value))

    db.commit()
    db.refresh(week)
    return {"week_id": week.id, "status": "updated"}


def update_multiple_curriculum_weeks(
    db: Session,
    user_id: int,
    curriculum_id: int,
    week_updates: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Batch update multiple weeks atomically in a single transaction.
    Each entry needs: {"week_id": int, "updates": {...}}
    """
    verify_curriculum_ownership(db, user_id, curriculum_id)
    updated_ids = []

    for entry in week_updates:
        week_id = entry.get("week_id")
        updates = entry.get("updates", {})
        week = (
            db.query(CurriculumWeek)
            .filter(
                CurriculumWeek.id == week_id,
                CurriculumWeek.curriculum_id == curriculum_id,
            )
            .first()
        )
        if not week:
            raise ValueError(f"Week {week_id} not found in curriculum {curriculum_id}")

        allowed_fields = {
            "year", "month", "week", "unit", "topic",
            "planned_content", "suggested_activities",
            "assessment_or_revision", "status",
        }
        for key, value in updates.items():
            if key in allowed_fields:
                setattr(week, key, str(value))
        updated_ids.append(week_id)

    db.commit()
    return {"updated_week_ids": updated_ids, "count": len(updated_ids)}


# ============================================================
# ASSESSMENT AGENT TOOLS
# ============================================================

def get_curriculum_chapters(
    db: Session, user_id: int, curriculum_id: int
) -> List[str]:
    """Extract unique chapters/units from curriculum weeks."""
    verify_curriculum_ownership(db, user_id, curriculum_id)
    weeks = (
        db.query(CurriculumWeek.unit)
        .filter(CurriculumWeek.curriculum_id == curriculum_id)
        .distinct()
        .all()
    )
    chapters = []
    for (unit,) in weeks:
        if unit and unit.strip():
            cleaned = unit.strip()
            cl = cleaned.lower()
            if not (cl.startswith("midterm") or cl.startswith("final")
                    or "break" in cl or "revision" in cl or "exam" in cl):
                if cleaned not in chapters:
                    chapters.append(cleaned)
    return sorted(chapters)


def save_assessment_batch(
    db: Session,
    user_id: int,
    curriculum_id: int,
    assessment_type: str,
    portion: str,
    total_questions: int,
    difficulty_distribution: Dict[str, int],
    question_type_distribution: Dict[str, int],
    variation_count: int,
) -> int:
    """Create an assessment_batches row. Returns the batch_id."""
    verify_curriculum_ownership(db, user_id, curriculum_id)
    batch = AssessmentBatch(
        user_id=user_id,
        curriculum_id=curriculum_id,
        assessment_type=assessment_type,
        portion=portion,
        total_questions=total_questions,
        difficulty_distribution=difficulty_distribution,
        question_type_distribution=question_type_distribution,
        variation_count=variation_count,
    )
    db.add(batch)
    db.commit()
    db.refresh(batch)
    return int(getattr(batch, "id"))


def save_assessment_version(
    db: Session,
    batch_id: int,
    curriculum_id: int,
    variation_number: int,
    questions: List[Dict[str, Any]],
    validation_status: str,
) -> int:
    """Create an assessments row for one variation. Returns assessment_id."""
    a = Assessment(
        batch_id=batch_id,
        curriculum_id=curriculum_id,
        variation_number=variation_number,
        questions=questions,
        validation_status=validation_status,
    )
    db.add(a)
    db.commit()
    db.refresh(a)
    return int(getattr(a, "id"))


def get_assessment_batches(
    db: Session, user_id: int, curriculum_id: int
) -> List[Dict[str, Any]]:
    """List assessment batches for a curriculum with ownership check."""
    verify_curriculum_ownership(db, user_id, curriculum_id)
    batches = (
        db.query(AssessmentBatch)
        .filter(
            AssessmentBatch.user_id == user_id,
            AssessmentBatch.curriculum_id == curriculum_id,
        )
        .order_by(desc(AssessmentBatch.created_at))
        .all()
    )
    return [
        {
            "id": b.id,
            "assessment_type": b.assessment_type,
            "portion": b.portion,
            "total_questions": b.total_questions,
            "variation_count": b.variation_count,
            "created_at": b.created_at.isoformat() if b.created_at is not None else None,
        }
        for b in batches
    ]


def get_assessment(
    db: Session, assessment_id: int, user_id: int
) -> Optional[Dict[str, Any]]:
    """Load a single assessment version with ownership check via batch."""
    a = db.query(Assessment).filter(Assessment.id == assessment_id).first()
    if not a:
        return None
    # Verify ownership through batch
    batch = db.query(AssessmentBatch).filter(AssessmentBatch.id == a.batch_id).first()
    if not batch or getattr(batch, "user_id") != user_id:
        return None
    return {
        "id": a.id,
        "batch_id": a.batch_id,
        "variation_number": a.variation_number,
        "questions": a.questions,
        "validation_status": a.validation_status,
        "created_at": a.created_at.isoformat() if a.created_at is not None else None,
    }


def get_batch_with_assessments(
    db: Session, batch_id: int, user_id: int
) -> Optional[Dict[str, Any]]:
    """Load a batch and all its assessment versions with ownership check."""
    batch = (
        db.query(AssessmentBatch)
        .filter(AssessmentBatch.id == batch_id, AssessmentBatch.user_id == user_id)
        .first()
    )
    if not batch:
        return None
    assessments = (
        db.query(Assessment)
        .filter(Assessment.batch_id == batch_id)
        .order_by(Assessment.variation_number)
        .all()
    )
    return {
        "id": batch.id,
        "assessment_type": batch.assessment_type,
        "portion": batch.portion,
        "total_questions": batch.total_questions,
        "difficulty_distribution": batch.difficulty_distribution,
        "question_type_distribution": batch.question_type_distribution,
        "variation_count": batch.variation_count,
        "created_at": batch.created_at.isoformat() if batch.created_at is not None else None,
        "assessments": [
            {
                "id": a.id,
                "variation_number": a.variation_number,
                "questions": a.questions,
                "validation_status": a.validation_status,
            }
            for a in assessments
        ],
    }


def delete_assessment_batch(
    db: Session, batch_id: int, user_id: int
) -> bool:
    """Delete an assessment batch and its variations with ownership check."""
    batch = (
        db.query(AssessmentBatch)
        .filter(AssessmentBatch.id == batch_id, AssessmentBatch.user_id == user_id)
        .first()
    )
    if not batch:
        return False
    
    # Delete associated assessments first
    db.query(Assessment).filter(Assessment.batch_id == batch_id).delete()
    
    # Delete the batch
    db.delete(batch)
    db.commit()
    return True
