"""
TeacherOS Phase 2 — LangGraph Graph Construction

Builds two separate graphs:
1. Curriculum Agent: Conditional + HITL
2. Assessment Agent: Parallel + bounded retry
"""

from typing import cast, Any
from langgraph.graph import StateGraph, START, END

from agents.state import CurriculumAgentState, AssessmentAgentState
from agents.curriculum_agent import (
    load_memory_node,
    load_curriculum_node,
    interpret_and_plan_node,
    request_human_input_node,
    apply_changes_node,
    save_memory_node,
    route_after_plan,
    route_after_human,
)
from agents.assessment_agent import (
    create_blueprint_node,
    generate_and_validate_node,
    retry_failed_node,
    save_results_node,
    route_after_validate,
    route_after_retry,
)


# ============================================================
# CURRICULUM AGENT GRAPH
# ============================================================

def build_curriculum_graph():
    """
    Build the Curriculum Editing Agent graph.

    Flow:
    start → load_memory → load_curriculum → interpret_and_plan
      → (conditional) → request_human_input (INTERRUPT)
      → (conditional) → apply_changes → save_memory → END
                       or re-plan (modify/clarification)
                       or save_memory (rejected) → END
    """
    graph = StateGraph(cast(Any, CurriculumAgentState))

    # Add nodes
    graph.add_node("load_memory", load_memory_node)
    graph.add_node("load_curriculum", load_curriculum_node)
    graph.add_node("interpret_and_plan", interpret_and_plan_node)
    graph.add_node("request_human_input", request_human_input_node)
    graph.add_node("apply_changes", apply_changes_node)
    graph.add_node("save_memory", save_memory_node)

    # Add edges
    graph.add_edge(START, "load_memory")
    graph.add_edge("load_memory", "load_curriculum")
    graph.add_edge("load_curriculum", "interpret_and_plan")

    # After planning: always go to human input (clarification or approval)
    graph.add_conditional_edges(
        "interpret_and_plan",
        route_after_plan,
        {
            "request_human_input": "request_human_input",
        }
    )

    # After human input: apply, re-plan, or reject
    graph.add_conditional_edges(
        "request_human_input",
        route_after_human,
        {
            "apply_changes": "apply_changes",
            "interpret_and_plan": "interpret_and_plan",
            "save_memory": "save_memory",
        }
    )

    # After apply: save memory
    graph.add_edge("apply_changes", "save_memory")

    # Save memory → END
    graph.add_edge("save_memory", END)

    return graph


# ============================================================
# ASSESSMENT AGENT GRAPH
# ============================================================

def build_assessment_graph():
    """
    Build the Assessment Variant & Validation Agent graph.

    Flow:
    start → create_blueprint → generate_and_validate
      → (conditional) → retry_failed (if retryable) → save_results → END
                       or save_results → END
    """
    graph = StateGraph(cast(Any, AssessmentAgentState))

    # Add nodes
    graph.add_node("create_blueprint", create_blueprint_node)
    graph.add_node("generate_and_validate", generate_and_validate_node)
    graph.add_node("retry_failed", retry_failed_node)
    graph.add_node("save_results", save_results_node)

    # Add edges
    graph.add_edge(START, "create_blueprint")
    graph.add_edge("create_blueprint", "generate_and_validate")

    # After validation: retry if retryable, else save
    graph.add_conditional_edges(
        "generate_and_validate",
        route_after_validate,
        {
            "retry_failed": "retry_failed",
            "save_results": "save_results",
        }
    )

    # After retry: always save (no infinite loop)
    graph.add_conditional_edges(
        "retry_failed",
        route_after_retry,
        {
            "save_results": "save_results",
        }
    )

    # Save results → END
    graph.add_edge("save_results", END)

    return graph


# ============================================================
# COMPILED GRAPH FACTORY
# ============================================================

def get_compiled_curriculum_graph(checkpointer=None):
    """Compile the Curriculum Agent graph with optional checkpointer for HITL."""
    graph = build_curriculum_graph()
    return graph.compile(checkpointer=checkpointer)


def get_compiled_assessment_graph():
    """Compile the Assessment Agent graph (no checkpointer needed)."""
    graph = build_assessment_graph()
    return graph.compile()
