"""
TeacherOS Phase 2 — Deterministic Assessment Validation

All validation is done with Python logic, NOT Gemini calls.
Zero LLM tokens consumed for validation.
"""

import re
from typing import List, Dict, Any, Tuple


# The four allowed question types
ALLOWED_QUESTION_TYPES = {"MCQ", "Short Answer", "Descriptive Answer", "Long Answer"}

# Allowed difficulty levels
ALLOWED_DIFFICULTIES = {"Easy", "Medium", "Hard"}


def validate_variation(
    questions: List[Dict[str, Any]],
    expected_total: int,
    expected_difficulty: Dict[str, int],
    expected_types: Dict[str, int],
) -> Tuple[bool, List[str]]:
    """
    Validate a single assessment variation using deterministic Python logic.

    Returns (is_valid, list_of_error_strings).
    """
    errors = []

    # 1. Exact question count
    if len(questions) != expected_total:
        errors.append(
            f"Expected {expected_total} questions, got {len(questions)}"
        )

    # 2. Each question must have required fields
    for i, q in enumerate(questions):
        qn = i + 1

        if not q.get("question", "").strip():
            errors.append(f"Q{qn}: Missing question text")

        if not q.get("answer", "").strip() and not q.get("correct_answer", "").strip():
            errors.append(f"Q{qn}: Missing answer")

        q_type = q.get("question_type", "") or q.get("type", "")
        if q_type not in ALLOWED_QUESTION_TYPES:
            errors.append(f"Q{qn}: Invalid question type '{q_type}'")

        difficulty = q.get("difficulty", "")
        if difficulty not in ALLOWED_DIFFICULTIES:
            errors.append(f"Q{qn}: Invalid difficulty '{difficulty}'")

        # MCQ must have options
        if q_type == "MCQ":
            options = q.get("options", [])
            if not options or len(options) < 2:
                errors.append(f"Q{qn}: MCQ must have at least 2 options")

    # 3. Difficulty distribution
    actual_diff = {}
    for q in questions:
        d = q.get("difficulty", "Unknown")
        actual_diff[d] = actual_diff.get(d, 0) + 1

    for level, expected_count in expected_difficulty.items():
        actual_count = actual_diff.get(level, 0)
        if actual_count != expected_count:
            errors.append(
                f"Difficulty '{level}': expected {expected_count}, got {actual_count}"
            )

    # 4. Question type distribution
    actual_types = {}
    for q in questions:
        t = q.get("question_type", "") or q.get("type", "")
        actual_types[t] = actual_types.get(t, 0) + 1

    for qtype, expected_count in expected_types.items():
        actual_count = actual_types.get(qtype, 0)
        if actual_count != expected_count:
            errors.append(
                f"Type '{qtype}': expected {expected_count}, got {actual_count}"
            )

    # 5. Check for obvious duplicate questions (normalized text comparison)
    seen_questions = set()
    for i, q in enumerate(questions):
        normalized = _normalize_text(q.get("question", ""))
        if normalized in seen_questions:
            errors.append(f"Q{i + 1}: Appears to be a duplicate question")
        seen_questions.add(normalized)

    is_valid = len(errors) == 0
    return is_valid, errors


def _normalize_text(text: str) -> str:
    """Normalize text for duplicate detection — lowercase, strip, collapse whitespace."""
    text = text.lower().strip()
    text = re.sub(r'\s+', ' ', text)
    return text
