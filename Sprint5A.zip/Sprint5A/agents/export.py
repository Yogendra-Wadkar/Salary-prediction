"""
TeacherOS Phase 2 — Assessment Export Templates & Helpers
Generates professional examination-style Question Papers and Answer Keys
with proper mathematical rendering and clean print layout.
"""

from typing import Dict, Any, List
import zipfile
import io


def render_question_paper_html(assessment: Dict[str, Any], batch_meta: Dict[str, Any]) -> str:
    """
    Generate clean, printable examination paper HTML (questions only, no answers/explanations).
    """
    questions: List[Dict[str, Any]] = assessment.get("questions") or []
    var_num = assessment.get("variation_number", 1)
    a_type = batch_meta.get("assessment_type", "Assessment")
    portion = batch_meta.get("portion", "General Portion")
    total_q = len(questions)

    q_items_html = []
    for idx, q in enumerate(questions):
        q_num = idx + 1
        q_type = q.get("question_type") or q.get("type") or "Question"
        diff = q.get("difficulty") or ""
        q_text = q.get("question") or ""

        # Options for MCQ
        options_html = ""
        opts = q.get("options") or []
        if opts:
            opt_entries = []
            labels = ["(A)", "(B)", "(C)", "(D)", "(E)", "(F)"]
            for o_idx, opt in enumerate(opts):
                lbl = labels[o_idx] if o_idx < len(labels) else f"({o_idx+1})"
                # Strip pre-existing label prefix if present
                clean_opt = opt
                for prefix in ["A)", "B)", "C)", "D)", "(A)", "(B)", "(C)", "(D)", "A.", "B.", "C.", "D."]:
                    if clean_opt.strip().startswith(prefix):
                        clean_opt = clean_opt.strip()[len(prefix):].strip()
                        break
                opt_entries.append(f"<div class='exam-option'><strong>{lbl}</strong> {clean_opt}</div>")
            options_html = f"<div class='exam-options-grid'>{''.join(opt_entries)}</div>"

        # Answer space for non-MCQ
        answer_space_html = ""
        q_type_lower = q_type.lower()
        if "short" in q_type_lower:
            answer_space_html = "<div class='exam-answer-space short'><span class='answer-space-label'>Answer:</span></div>"
        elif "descriptive" in q_type_lower:
            answer_space_html = "<div class='exam-answer-space descriptive'><span class='answer-space-label'>Working / Answer:</span></div>"
        elif "long" in q_type_lower:
            answer_space_html = "<div class='exam-answer-space long'><span class='answer-space-label'>Detailed Solution:</span></div>"

        diff_tag = f" &bull; {diff}" if diff else ""
        q_items_html.append(f"""
        <div class="exam-question-item">
            <div class="exam-question-header">
                <span class="exam-q-num">Q{q_num}.</span>
                <span class="exam-q-type">[{q_type}{diff_tag}]</span>
            </div>
            <div class="exam-q-text">{q_text}</div>
            {options_html}
            {answer_space_html}
        </div>
        """)

    body_content = "\n".join(q_items_html)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Question Paper - Version {var_num}</title>
    <!-- MathJax 3 for crisp LaTeX typesetting -->
    <script>
        window.MathJax = {{
            tex: {{
                inlineMath: [['$', '$'], ['\\\\(', '\\\\)']],
                displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']],
                processEscapes: true
            }}
        }};
    </script>
    <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
    <style>
        @page {{
            size: A4 portrait;
            margin: 15mm 15mm 15mm 15mm;
        }}
        @media print {{
            body {{ -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
            .no-print {{ display: none !important; }}
        }}
        * {{ box-sizing: border-box; }}
        body {{
            font-family: 'Times New Roman', Times, serif, 'Segoe UI', Arial, sans-serif;
            color: #111;
            line-height: 1.5;
            font-size: 11pt;
            background: #fff;
            margin: 0;
            padding: 15px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }}
        .exam-header {{
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 8px;
            margin-bottom: 12px;
        }}
        .exam-school-title {{
            font-size: 16pt;
            font-weight: bold;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin: 0 0 4px 0;
        }}
        .exam-sub-title {{
            font-size: 12pt;
            font-weight: 600;
            margin: 0 0 6px 0;
        }}
        .exam-meta-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 10pt;
            margin-top: 6px;
        }}
        .exam-meta-table td {{
            padding: 3px 0;
        }}
        .exam-student-meta {{
            border: 1px solid #444;
            padding: 8px 12px;
            margin: 12px 0;
            font-size: 10pt;
            display: flex;
            justify-content: space-between;
        }}
        .exam-instructions {{
            font-size: 9.5pt;
            font-style: italic;
            margin-bottom: 16px;
            padding-bottom: 6px;
            border-bottom: 1px dashed #666;
            color: #333;
        }}
        .exam-question-item {{
            margin-bottom: 16px;
            page-break-inside: avoid;
        }}
        .exam-question-header {{
            font-weight: bold;
            margin-bottom: 4px;
        }}
        .exam-q-num {{
            font-size: 11.5pt;
            margin-right: 4px;
            color: #000;
        }}
        .exam-q-type {{
            font-size: 9.5pt;
            color: #444;
            font-style: italic;
        }}
        .exam-q-text {{
            font-size: 11pt;
            margin-left: 20px;
            margin-bottom: 8px;
        }}
        .exam-options-grid {{
            margin-left: 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 6px 20px;
            margin-bottom: 8px;
        }}
        .exam-option {{
            font-size: 10.5pt;
        }}
        .exam-answer-space {{
            margin-left: 20px;
            border: 1px dashed #aaa;
            background: #fafafa;
            border-radius: 4px;
            margin-top: 6px;
            padding: 4px 8px;
        }}
        .exam-answer-space.short {{ min-height: 50px; }}
        .exam-answer-space.descriptive {{ min-height: 90px; }}
        .exam-answer-space.long {{ min-height: 140px; }}
        .answer-space-label {{
            font-size: 8.5pt;
            color: #888;
            font-style: italic;
        }}
        .exam-footer {{
            margin-top: 25px;
            text-align: center;
            font-size: 9pt;
            color: #666;
            border-top: 1px solid #ccc;
            padding-top: 6px;
        }}
    </style>
</head>
<body>
    <div class="exam-header">
        <div class="exam-school-title">TeacherOS Examination Paper</div>
        <div class="exam-sub-title">{a_type} &mdash; Set {var_num} (Version {var_num})</div>
        <table class="exam-meta-table">
            <tr>
                <td style="width: 50%;"><strong>Portion / Topic:</strong> {portion}</td>
                <td style="text-align: right; width: 50%;"><strong>Total Questions:</strong> {total_q}</td>
            </tr>
        </table>
    </div>

    <div class="exam-student-meta">
        <span><strong>Student Name:</strong> ____________________________________</span>
        <span><strong>Roll No:</strong> ____________</span>
        <span><strong>Date:</strong> ____________</span>
    </div>

    <div class="exam-instructions">
        <strong>General Instructions:</strong> Read each question carefully. Answer all questions in the space provided. For multiple-choice questions, select the single best option.
    </div>

    <div class="exam-questions-container">
        {body_content}
    </div>

    <div class="exam-footer">
        *** End of Question Paper &mdash; Set {var_num} ***
    </div>
</body>
</html>"""


def render_answer_key_html(assessment: Dict[str, Any], batch_meta: Dict[str, Any]) -> str:
    """
    Generate clean, teacher-ready Answer Key & Explanation Guide HTML.
    """
    questions: List[Dict[str, Any]] = assessment.get("questions") or []
    var_num = assessment.get("variation_number", 1)
    a_type = batch_meta.get("assessment_type", "Assessment")
    portion = batch_meta.get("portion", "General Portion")
    total_q = len(questions)

    items_html = []
    for idx, q in enumerate(questions):
        q_num = idx + 1
        q_type = q.get("question_type") or q.get("type") or "Question"
        q_text = q.get("question") or ""
        ans = q.get("correct_answer") or q.get("answer") or "N/A"
        exp = q.get("explanation") or q.get("answer_explanation") or "No explanation provided."

        items_html.append(f"""
        <div class="key-item">
            <div class="key-header">
                <span class="key-qnum">Question {q_num}</span>
                <span class="key-qtype">[{q_type}]</span>
            </div>
            <div class="key-qtext"><strong>Problem:</strong> {q_text}</div>
            <div class="key-answer-box">
                <strong>Correct Answer:</strong> {ans}
            </div>
            <div class="key-explanation">
                <strong>Explanation / Solution:</strong>
                <div class="key-exp-body">{exp}</div>
            </div>
        </div>
        """)

    body_content = "\n".join(items_html)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Answer Key - Version {var_num}</title>
    <!-- MathJax 3 for crisp LaTeX typesetting -->
    <script>
        window.MathJax = {{
            tex: {{
                inlineMath: [['$', '$'], ['\\\\(', '\\\\)']],
                displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']],
                processEscapes: true
            }}
        }};
    </script>
    <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
    <style>
        @page {{
            size: A4 portrait;
            margin: 15mm 15mm 15mm 15mm;
        }}
        @media print {{
            body {{ -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
            .no-print {{ display: none !important; }}
        }}
        * {{ box-sizing: border-box; }}
        body {{
            font-family: 'Times New Roman', Times, serif, 'Segoe UI', Arial, sans-serif;
            color: #111;
            line-height: 1.5;
            font-size: 11pt;
            background: #fff;
            margin: 0;
            padding: 15px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }}
        .key-header-main {{
            text-align: center;
            border-bottom: 2px solid #1e293b;
            padding-bottom: 8px;
            margin-bottom: 15px;
        }}
        .key-title {{
            font-size: 16pt;
            font-weight: bold;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin: 0 0 4px 0;
            color: #0f172a;
        }}
        .key-sub {{
            font-size: 12pt;
            font-weight: 600;
            color: #334155;
            margin: 0 0 6px 0;
        }}
        .key-item {{
            margin-bottom: 16px;
            padding: 10px 14px;
            background: #fff;
            border: 1px solid #cbd5e1;
            border-radius: 4px;
            page-break-inside: avoid;
        }}
        .key-header {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 6px;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 4px;
        }}
        .key-qnum {{
            font-weight: bold;
            color: #0f172a;
            font-size: 11.5pt;
        }}
        .key-qtype {{
            font-style: italic;
            color: #64748b;
            font-size: 9.5pt;
        }}
        .key-qtext {{
            font-size: 10.5pt;
            margin-bottom: 8px;
        }}
        .key-answer-box {{
            background: #f0fdf4;
            border-left: 4px solid #16a34a;
            padding: 6px 10px;
            font-size: 11pt;
            color: #14532d;
            margin-bottom: 6px;
        }}
        .key-explanation {{
            font-size: 10pt;
            color: #334155;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 6px 10px;
            border-radius: 4px;
        }}
        .key-exp-body {{
            margin-top: 4px;
            line-height: 1.45;
        }}
        .key-footer {{
            margin-top: 25px;
            text-align: center;
            font-size: 9pt;
            color: #666;
            border-top: 1px solid #ccc;
            padding-top: 6px;
        }}
    </style>
</head>
<body>
    <div class="key-header-main">
        <div class="key-title">TeacherOS Answer Key &amp; Solution Guide</div>
        <div class="key-sub">{a_type} &mdash; Set {var_num} (Teacher Edition)</div>
        <div style="font-size: 10pt; margin-top: 4px;"><strong>Portion / Topic:</strong> {portion} &nbsp;|&nbsp; <strong>Total Questions:</strong> {total_q}</div>
    </div>

    <div class="key-questions-container">
        {body_content}
    </div>

    <div class="key-footer">
        *** TeacherOS Assessment Solution Guide &mdash; Set {var_num} ***
    </div>
</body>
</html>"""


def create_batch_zip(batch_meta: Dict[str, Any], assessments: List[Dict[str, Any]]) -> bytes:
    """
    Create an in-memory ZIP archive containing Question Papers and Answer Keys
    for all variations in the batch.
    """
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
        for a in assessments:
            v_num = a.get("variation_number", 1)

            # 1. Question Paper
            qp_html = render_question_paper_html(a, batch_meta)
            zip_file.writestr(f"Version_{v_num}_Question_Paper.html", qp_html)

            # 2. Answer Key
            ak_html = render_answer_key_html(a, batch_meta)
            zip_file.writestr(f"Version_{v_num}_Answer_Key.html", ak_html)

    zip_buffer.seek(0)
    return zip_buffer.getvalue()
