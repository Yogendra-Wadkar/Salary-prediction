"""
TeacherOS Phase 2 — Assessment Variant & Validation Agent

Parallel fan-out/fan-in workflow with bounded retry.
- Max 3 concurrent Gemini calls
- Max 1 retry per failed variation
- Successful variations never regenerated
- Deterministic Python validation (no Gemini for validation)
"""

import json
import re
from typing import Dict, Any, List, Optional
from concurrent.futures import ThreadPoolExecutor

from langchain_core.runnables import RunnableConfig

from pydantic import BaseModel, Field, field_validator

from rag.rag_pipeline import get_llm, get_structured_llm
from agents.state import AssessmentAgentState, VariationResult
from agents.tools import search_syllabus, save_assessment_batch, save_assessment_version
from agents.validation import validate_variation
from prompts.agent_prompts import (
    ASSESSMENT_AGENT_SYSTEM_PROMPT,
    ASSESSMENT_AGENT_HUMAN_TEMPLATE,
)


# ============================================================
# STRUCTURED OUTPUT SCHEMA
# ============================================================

class AssessmentQuestion(BaseModel):
    question: str = Field(default="", description="The question text")
    question_type: str = Field(default="MCQ", description="MCQ | Short Answer | Descriptive Answer | Long Answer")
    difficulty: str = Field(default="Medium", description="Easy | Medium | Hard")
    options: Optional[List[str]] = Field(default_factory=list, description="Options for MCQ (4 items)")
    correct_answer: str = Field(default="", description="The correct answer")
    explanation: str = Field(default="", description="Brief explanation of why this is correct")
    topic: Optional[str] = Field(default="", description="The topic this question covers")

    @field_validator("options", mode="before")
    @classmethod
    def normalize_options(cls, v):
        if v is None:
            return []
        if isinstance(v, list):
            return [str(opt) for opt in v if opt is not None]
        return []

    @field_validator("topic", mode="before")
    @classmethod
    def normalize_topic(cls, v):
        return str(v) if v is not None else ""

    @field_validator("question", mode="before")
    @classmethod
    def normalize_question(cls, v):
        return str(v) if v is not None else ""

    @field_validator("question_type", mode="before")
    @classmethod
    def normalize_question_type(cls, v):
        return str(v) if v is not None else "MCQ"

    @field_validator("difficulty", mode="before")
    @classmethod
    def normalize_difficulty(cls, v):
        return str(v) if v is not None else "Medium"

    @field_validator("correct_answer", mode="before")
    @classmethod
    def normalize_correct_answer(cls, v):
        return str(v) if v is not None else ""

    @field_validator("explanation", mode="before")
    @classmethod
    def normalize_explanation(cls, v):
        return str(v) if v is not None else ""


class AssessmentOutput(BaseModel):
    questions: List[AssessmentQuestion] = Field(default_factory=list)

    @field_validator("questions", mode="before")
    @classmethod
    def normalize_questions(cls, v):
        if v is None:
            return []
        if isinstance(v, list):
            return v
        return []


# Maximum concurrent Gemini calls
MAX_CONCURRENT = 3


def _is_quota_error(err: Any) -> bool:
    """Check if an exception is a Gemini 429 quota/resource exhaustion error."""
    err_str = str(err)
    return "429" in err_str or "RESOURCE_EXHAUSTED" in err_str or "ResourceExhausted" in err_str


# ============================================================
# SINGLE VARIATION GENERATION
# ============================================================

def _generate_single_variation(
    variation_number: int,
    total_variations: int,
    assessment_type: str,
    portion: str,
    total_questions: int,
    difficulty_distribution: Dict[str, int],
    question_type_distribution: Dict[str, int],
    syllabus_context: str,
) -> List[Dict[str, Any]]:
    """
    Generate one assessment variation using Gemini structured output.
    Single direct call with max_retries=0 (no hidden retries, no fallback calls).
    """
    # Format distributions for prompt
    difficulty_text = "\n".join(
        f"  {level}: {count}" for level, count in difficulty_distribution.items()
    )
    type_text = "\n".join(
        f"  {qtype}: {count}" for qtype, count in question_type_distribution.items()
    )

    human_message = ASSESSMENT_AGENT_HUMAN_TEMPLATE.format(
        assessment_type=assessment_type,
        portion=portion,
        total_questions=total_questions,
        difficulty_text=difficulty_text,
        type_text=type_text,
        syllabus_context=syllabus_context,
        variation_number=variation_number,
        total_variations=total_variations,
    )

    structured_llm = get_structured_llm(
        schema=AssessmentOutput,
        model="gemini-3.7-flash",
        max_output_tokens=8192,
        thinking_level="low",
        api_key_env="GOOGLE_API_KEY_ASSESSMENT_AGENT",
        max_retries=0,
    )

    try:
        result = structured_llm.invoke([
            {"role": "system", "content": ASSESSMENT_AGENT_SYSTEM_PROMPT},
            {"role": "user", "content": human_message},
        ])

        if isinstance(result, BaseModel):
            data = result.model_dump()
        elif isinstance(result, dict):
            data = result
        else:
            data = {"questions": []}

        return data.get("questions", [])

    except Exception as e:
        print(f"[Assessment Agent] Structured call failed for V{variation_number}: {e}")
        raise e


# ============================================================
# NODE: create_blueprint
# ============================================================

def create_blueprint_node(state: AssessmentAgentState) -> Dict[str, Any]:
    """
    Create the assessment blueprint and retrieve syllabus context.
    """
    # Retrieve syllabus context using bounded k
    context = search_syllabus(
        curriculum_id=state["curriculum_id"],
        query=f"{state['portion']} {state['assessment_type']}",
        k=4,
    )

    blueprint = {
        "assessment_type": state["assessment_type"],
        "portion": state["portion"],
        "total_questions": state["total_questions"],
        "difficulty_distribution": state["difficulty_distribution"],
        "question_type_distribution": state["question_type_distribution"],
        "variation_count": state["variation_count"],
    }

    return {
        "blueprint": blueprint,
        "syllabus_context": context,
    }


# ============================================================
# NODE: generate_and_validate
# ============================================================

def generate_and_validate_node(state: AssessmentAgentState) -> Dict[str, Any]:
    """
    Fan-out: generate all variations with bounded concurrency (max 3).
    Then validate each with deterministic Python logic.
    """
    blueprint = state.get("blueprint") or {}
    variation_count = blueprint.get("variation_count", 1)
    syllabus_context = state.get("syllabus_context") or ""

    variations: List[VariationResult] = []

    # Use ThreadPoolExecutor for bounded concurrency
    def _generate_one(var_num: int) -> VariationResult:
        try:
            questions = _generate_single_variation(
                variation_number=var_num,
                total_variations=variation_count,
                assessment_type=blueprint["assessment_type"],
                portion=blueprint["portion"],
                total_questions=blueprint["total_questions"],
                difficulty_distribution=blueprint["difficulty_distribution"],
                question_type_distribution=blueprint["question_type_distribution"],
                syllabus_context=syllabus_context,
            )

            is_valid, errors = validate_variation(
                questions=questions,
                expected_total=blueprint["total_questions"],
                expected_difficulty=blueprint["difficulty_distribution"],
                expected_types=blueprint["question_type_distribution"],
            )

            return VariationResult(
                variation_number=var_num,
                questions=questions,
                validation_status="valid" if is_valid else "failed",
                validation_errors=errors if not is_valid else None,
                retry_count=0,
            )
        except Exception as e:
            if _is_quota_error(e):
                return VariationResult(
                    variation_number=var_num,
                    questions=[],
                    validation_status="failed",
                    validation_errors=[f"429 RESOURCE_EXHAUSTED: {str(e)}"],
                    retry_count=0,
                )
            return VariationResult(
                variation_number=var_num,
                questions=[],
                validation_status="failed",
                validation_errors=[f"Generation error: {str(e)}"],
                retry_count=0,
            )

    # Bounded concurrency: max 3 concurrent
    with ThreadPoolExecutor(max_workers=MAX_CONCURRENT) as executor:
        futures = {
            executor.submit(_generate_one, i + 1): i + 1
            for i in range(variation_count)
        }
        for future in futures:
            result = future.result()
            variations.append(result)

    # Sort by variation number
    variations.sort(key=lambda v: v["variation_number"])

    return {"variations": variations}


# ============================================================
# NODE: retry_failed
# ============================================================

def retry_failed_node(state: AssessmentAgentState) -> Dict[str, Any]:
    """
    Retry ONLY failed variations with retry_count == 0.
    Max 1 retry per variation. Successful variations untouched.
    After retry, variations with retry_count == 1 that still fail
    are marked as 'failed' — no further retry.
    """
    variations: List[VariationResult] = list(state.get("variations") or [])
    blueprint = state.get("blueprint") or {}
    syllabus_context = state.get("syllabus_context") or ""

    # Find retryable failures
    retryable = [
        (i, v) for i, v in enumerate(variations)
        if v["validation_status"] == "failed" and v["retry_count"] == 0
    ]

    if not retryable:
        return {"variations": variations}

    quota_errors = []

    def _retry_one(idx: int, v: VariationResult) -> tuple:
        try:
            questions = _generate_single_variation(
                variation_number=v["variation_number"],
                total_variations=blueprint["variation_count"],
                assessment_type=blueprint["assessment_type"],
                portion=blueprint["portion"],
                total_questions=blueprint["total_questions"],
                difficulty_distribution=blueprint["difficulty_distribution"],
                question_type_distribution=blueprint["question_type_distribution"],
                syllabus_context=syllabus_context,
            )

            is_valid, errors = validate_variation(
                questions=questions,
                expected_total=blueprint["total_questions"],
                expected_difficulty=blueprint["difficulty_distribution"],
                expected_types=blueprint["question_type_distribution"],
            )

            updated = VariationResult(
                variation_number=v["variation_number"],
                questions=questions,
                validation_status="valid" if is_valid else "failed",
                validation_errors=errors if not is_valid else None,
                retry_count=1,  # Incremented — will NOT be retried again
            )
            return idx, updated, None
        except Exception as e:
            if _is_quota_error(e):
                updated = VariationResult(
                    variation_number=v["variation_number"],
                    questions=[],
                    validation_status="failed",
                    validation_errors=[f"429 RESOURCE_EXHAUSTED: {str(e)}"],
                    retry_count=1,
                )
                return idx, updated, e
            updated = VariationResult(
                variation_number=v["variation_number"],
                questions=[],
                validation_status="failed",
                validation_errors=[f"Retry generation error: {str(e)}"],
                retry_count=1,
            )
            return idx, updated, None

    # Bounded retry concurrency: max 3 concurrent
    with ThreadPoolExecutor(max_workers=MAX_CONCURRENT) as executor:
        futures = {
            executor.submit(_retry_one, idx, v): idx
            for idx, v in retryable
        }
        for future in futures:
            idx, updated, q_err = future.result()
            variations[idx] = updated
            if q_err is not None:
                quota_errors.append(q_err)

    # When the allowed retry is exhausted and quota failure occurred:
    # A quota failure must produce a clear terminal failure state
    if quota_errors:
        err = quota_errors[0]
        raise RuntimeError(f"Gemini 429 RESOURCE_EXHAUSTED: {str(err)}")

    return {"variations": variations}


# ============================================================
# NODE: save_results
# ============================================================

def save_results_node(state: AssessmentAgentState, config: RunnableConfig) -> Dict[str, Any]:
    """Save the batch and all variation results to PostgreSQL."""
    db = config.get("configurable", {}).get("db")
    if db is None:
        return {"batch_id": None, "saved_assessment_ids": []}

    blueprint = state.get("blueprint") or {}

    # Create batch
    batch_id = save_assessment_batch(
        db=db,
        user_id=state["user_id"],
        curriculum_id=state["curriculum_id"],
        assessment_type=blueprint.get("assessment_type", "Quiz"),
        portion=blueprint.get("portion", "Full Curriculum"),
        total_questions=blueprint.get("total_questions", 10),
        difficulty_distribution=blueprint.get("difficulty_distribution", {}),
        question_type_distribution=blueprint.get("question_type_distribution", {}),
        variation_count=blueprint.get("variation_count", 1),
    )

    # Save each variation
    saved_ids = []
    for v in (state.get("variations") or []):
        aid = save_assessment_version(
            db=db,
            batch_id=batch_id,
            curriculum_id=state["curriculum_id"],
            variation_number=v["variation_number"],
            questions=v.get("questions") or [],
            validation_status=v["validation_status"],
        )
        saved_ids.append(aid)

    return {"batch_id": batch_id, "saved_assessment_ids": saved_ids}


# ============================================================
# ROUTING FUNCTIONS
# ============================================================

def route_after_validate(state: AssessmentAgentState) -> str:
    """
    After generation+validation, check if any failed variations
    are retryable (retry_count == 0). If yes, retry. Otherwise finalize.
    """
    variations = state.get("variations") or []
    retryable = [
        v for v in variations
        if v["validation_status"] == "failed" and v["retry_count"] == 0
    ]
    if retryable:
        return "retry_failed"
    return "save_results"


def route_after_retry(state: AssessmentAgentState) -> str:
    """After retry, always go to save_results. No further retry."""
    return "save_results"
