"""
TeacherOS Phase 2 — Agent Memory

Layer B (application memory): concise structured summaries stored
in the agent_memory PostgreSQL table, scoped by
user_id + curriculum_id + agent_type.
"""

from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from backend.models import AgentMemory


def get_memories(
    db: Session,
    user_id: int,
    curriculum_id: int,
    agent_type: str,
    limit: int = 10,
) -> List[Dict[str, Any]]:
    """
    Load the most recent memories for the given scope.
    Returns at most `limit` entries (default 10).
    """
    rows = (
        db.query(AgentMemory)
        .filter(
            AgentMemory.user_id == user_id,
            AgentMemory.curriculum_id == curriculum_id,
            AgentMemory.agent_type == agent_type,
        )
        .order_by(AgentMemory.created_at.desc())
        .limit(limit)
        .all()
    )

    return [
        {
            "id": row.id,
            "memory_type": row.memory_type,
            "content": row.content,
            "metadata": row.metadata_ or {},
            "created_at": row.created_at.isoformat() if row.created_at is not None else None,
        }
        for row in reversed(rows)  # Chronological order
    ]


def save_memory(
    db: Session,
    user_id: int,
    curriculum_id: int,
    agent_type: str,
    memory_type: str,
    content: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> AgentMemory:
    """
    Persist a concise agent memory entry.

    memory_type should be one of: 'action', 'preference', 'rejection'
    """
    entry = AgentMemory(
        user_id=user_id,
        curriculum_id=curriculum_id,
        agent_type=agent_type,
        memory_type=memory_type,
        content=content,
        metadata_=metadata or {},
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry
