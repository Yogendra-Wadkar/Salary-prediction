"""
TeacherOS Phase 2 — Typed LangGraph State Definitions

CurriculumAgentState:  Conditional + HITL workflow
AssessmentAgentState:  Parallel fan-out/fan-in workflow
"""

from typing import Optional, List, Dict, Any
from typing_extensions import TypedDict


# ============================================================
# CURRICULUM AGENT STATE
# ============================================================

class CurriculumAgentState(TypedDict):
    # Identity
    user_id: int
    curriculum_id: int
    thread_id: str

    # Input
    user_request: str

    # Context loaded by tools
    curriculum_data: Optional[Dict[str, Any]]
    syllabus_context: Optional[str]
    memory_context: Optional[List[Dict[str, Any]]]

    # Planning
    proposed_changes: Optional[List[Dict[str, Any]]]
    clarification_needed: Optional[str]
    clarification_response: Optional[str]

    # HITL
    human_decision: Optional[str]        # "approved" | "rejected" | "modify"
    modify_instruction: Optional[str]

    # Execution
    execution_result: Optional[Dict[str, Any]]


# ============================================================
# ASSESSMENT VARIATION RESULT
# ============================================================

class VariationResult(TypedDict):
    variation_number: int
    questions: Optional[List[Dict[str, Any]]]
    validation_status: str                     # "valid" | "failed"
    validation_errors: Optional[List[str]]
    retry_count: int                           # 0 = initial, 1 = retried once (max)


# ============================================================
# ASSESSMENT AGENT STATE
# ============================================================

class AssessmentAgentState(TypedDict):
    # Identity
    user_id: int
    curriculum_id: int

    # Input (from teacher form)
    assessment_type: str
    portion: str
    total_questions: int
    difficulty_distribution: Dict[str, int]
    question_type_distribution: Dict[str, int]
    variation_count: int

    # Context
    syllabus_context: Optional[str]

    # Generation
    blueprint: Optional[Dict[str, Any]]
    variations: Optional[List[VariationResult]]

    # Persistence
    batch_id: Optional[int]
    saved_assessment_ids: Optional[List[int]]
