"""
TeacherOS Phase 2 — Curriculum Editing Agent

Conditional + Human-in-the-Loop workflow using LangGraph.
Uses interrupt() for HITL approval/clarification.
"""

import json
import re
import time
from typing import Dict, Any, Optional

from langgraph.types import interrupt
from langchain_core.runnables import RunnableConfig

from rag.rag_pipeline import get_llm
from agents.state import CurriculumAgentState
from agents.tools import (
    get_curriculum, get_curriculum_weeks, search_syllabus,
    update_multiple_curriculum_weeks,
)
from agents.memory import get_memories, save_memory
from prompts.agent_prompts import (
    CURRICULUM_AGENT_SYSTEM_PROMPT,
    CURRICULUM_AGENT_HUMAN_TEMPLATE,
)


def _extract_text_content(content: Any) -> str:
    """Safely extract plain text from LangChain response content (str or list of dicts/blocks)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for part in content:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, dict):
                parts.append(part.get("text", ""))
            elif hasattr(part, "text"):
                parts.append(str(part.text))
        return "".join(parts)
    return str(content)


def _parse_llm_json(raw_text: str) -> dict:
    """Extract and parse JSON from LLM output with support for markdown code blocks."""
    cleaned = raw_text.strip()
    match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", cleaned)
    if match:
        cleaned = match.group(1).strip()
    return json.loads(cleaned)


def _get_db(config: RunnableConfig):
    """Extract the SQLAlchemy db session from LangGraph config."""
    return config.get("configurable", {}).get("db")


# ============================================================
# NODE: load_memory
# ============================================================

def load_memory_node(state: CurriculumAgentState, config: RunnableConfig) -> Dict[str, Any]:
    """Load recent agent memories for context."""
    db = _get_db(config)
    if db is None:
        return {"memory_context": []}
    memories = get_memories(
        db=db,
        user_id=state["user_id"],
        curriculum_id=state["curriculum_id"],
        agent_type="curriculum",
    )
    return {"memory_context": memories}


# ============================================================
# NODE: load_curriculum
# ============================================================

def load_curriculum_node(state: CurriculumAgentState, config: RunnableConfig) -> Dict[str, Any]:
    """Load the current curriculum and its weeks from PostgreSQL."""
    db = _get_db(config)
    if db is None:
        return {"curriculum_data": None}
    curriculum = get_curriculum(db, state["user_id"], state["curriculum_id"])
    weeks = get_curriculum_weeks(db, state["user_id"], state["curriculum_id"])
    curriculum["weeks"] = weeks
    return {"curriculum_data": curriculum}


# ============================================================
# NODE: interpret_and_plan
# ============================================================

def interpret_and_plan_node(state: CurriculumAgentState) -> Dict[str, Any]:
    """
    Use Gemini to interpret the teacher's request and either:
    - Ask for clarification (set clarification_needed)
    - Propose specific changes (set proposed_changes)
    """
    curriculum_data = state.get("curriculum_data", {})
    weeks = curriculum_data.get("weeks", []) if curriculum_data else []

    # Format weeks for the prompt (including all content fields)
    weeks_text = "\n".join(
        f"  Week ID {w['id']}: {w['month']} {w['week']} | "
        f"Unit: {w['unit']} | Topic: {w['topic']} | "
        f"Content: {w['planned_content']} | "
        f"Activities: {w.get('suggested_activities', '')} | "
        f"Assessment: {w.get('assessment_or_revision', '')} | "
        f"Status: {w['status']}"
        for w in weeks
    )

    # Determine if syllabus context is needed
    request_lower = (state.get("user_request") or "").lower()
    needs_syllabus = any(
        kw in request_lower
        for kw in ["add topic", "add chapter", "include", "syllabus", "missing", "cover"]
    )

    syllabus_section = ""
    if needs_syllabus:
        context = search_syllabus(
            curriculum_id=state["curriculum_id"],
            query=state["user_request"],
            k=4,
        )
        syllabus_section = f"SYLLABUS CONTEXT:\n{context}"
        state_update_syllabus = context
    else:
        syllabus_section = "SYLLABUS CONTEXT: Not needed for this request."
        state_update_syllabus = None

    # Format memory context
    memory_context = state.get("memory_context", [])
    if memory_context:
        memory_text = "\n".join(
            f"  - [{m['memory_type']}] {m['content']}" for m in memory_context
        )
        memory_section = f"RECENT AGENT HISTORY:\n{memory_text}"
    else:
        memory_section = "RECENT AGENT HISTORY: None"

    # Incorporate clarification response and/or modify instruction into the request
    user_request = state.get("user_request", "")
    clarification_response = state.get("clarification_response")
    modify_instruction = state.get("modify_instruction")

    if clarification_response:
        user_request = f"{user_request}\n\nTEACHER CLARIFICATION: {clarification_response}"
    if modify_instruction:
        user_request = f"{user_request}\n\nADDITIONAL INSTRUCTION: {modify_instruction}"

    # Build prompt
    human_message = CURRICULUM_AGENT_HUMAN_TEMPLATE.format(
        user_request=user_request,
        subject=curriculum_data.get("subject", "") if curriculum_data else "",
        grade=curriculum_data.get("grade", "") if curriculum_data else "",
        academic_year=curriculum_data.get("academic_year", "") if curriculum_data else "",
        curriculum_weeks=weeks_text,
        syllabus_section=syllabus_section,
        memory_section=memory_section,
    )

    # Call Gemini — strictly gemini-3.7-flash with Key 4 (no fallback to other models)
    model_name = "gemini-3.7-flash"
    max_retries = 3
    response = None
    last_err = None

    for attempt in range(max_retries):
        try:
            llm = get_llm(
                model=model_name,
                max_output_tokens=4096,
                thinking_level="low",
                api_key_env="GOOGLE_API_KEY_CURRICULUM_AGENT",
                max_retries=2,
            )
            response = llm.invoke([
                {"role": "system", "content": CURRICULUM_AGENT_SYSTEM_PROMPT},
                {"role": "user", "content": human_message},
            ])
            break
        except Exception as e:
            last_err = e
            err_str = str(e)
            is_transient = any(
                code in err_str
                for code in ["503", "UNAVAILABLE", "429", "RESOURCE_EXHAUSTED", "high demand"]
            )
            if is_transient and attempt < max_retries - 1:
                wait_sec = 2 ** (attempt + 1)
                print(f"[Curriculum Agent] {model_name} transient error ({err_str[:80]}). Retrying in {wait_sec}s (attempt {attempt + 1}/{max_retries})...", flush=True)
                time.sleep(wait_sec)
                continue
            else:
                print(f"[Curriculum Agent] {model_name} invocation error: {err_str[:120]}", flush=True)
                break

    if response is None and last_err is not None:
        err_str = str(last_err)
        if "503" in err_str or "UNAVAILABLE" in err_str or "high demand" in err_str:
            raise RuntimeError("Google Gemini (gemini-3.7-flash) is currently experiencing temporary high demand (503). Please wait a moment and try your request again.")
        elif "429" in err_str or "RESOURCE_EXHAUSTED" in err_str:
            raise RuntimeError("API quota or rate limit exceeded for gemini-3.7-flash on Key 4 (429). Please verify your Key 4 quota in .env or try again in a moment.")
        raise last_err

    # Extract text content safely (Gemini 3.7 may return content as a list of blocks)
    raw_content = _extract_text_content(response.content if hasattr(response, "content") else str(response))

    # Parse JSON from LLM output
    try:
        parsed = _parse_llm_json(raw_content)
    except Exception as e:
        print(f"[Curriculum Agent] JSON parse error: {e}. Raw content: {raw_content[:200]}")
        return {
            "user_request": user_request,
            "clarification_needed": "I couldn't understand the request fully. Could you please rephrase what you'd like to change in the curriculum?",
            "clarification_response": None,
            "modify_instruction": None,
            "proposed_changes": None,
            "syllabus_context": state_update_syllabus,
        }

    if "clarification_needed" in parsed:
        return {
            "user_request": user_request,
            "clarification_needed": parsed["clarification_needed"],
            "clarification_response": None,
            "modify_instruction": None,
            "proposed_changes": None,
            "syllabus_context": state_update_syllabus,
        }

    return {
        "user_request": user_request,
        "clarification_needed": None,
        "clarification_response": None,
        "modify_instruction": None,
        "proposed_changes": parsed.get("proposed_changes", []),
        "syllabus_context": state_update_syllabus,
        "execution_result": {"summary": parsed.get("summary", "Changes proposed")},
    }


# ============================================================
# NODE: request_human_input (HITL interrupt)
# ============================================================

def request_human_input_node(state: CurriculumAgentState) -> Dict[str, Any]:
    """
    Interrupt the graph to get human approval/clarification.
    """
    if state.get("clarification_needed"):
        # Asking for clarification
        response = interrupt({
            "type": "clarification",
            "question": state["clarification_needed"],
            "proposed_changes": None,
        })
        return {
            "clarification_response": response.get("response", ""),
            "human_decision": None,
            "modify_instruction": None,
            "clarification_needed": None,
        }
    else:
        # Asking for approval of proposed changes
        response = interrupt({
            "type": "approval",
            "proposed_changes": state.get("proposed_changes", []),
            "summary": (state.get("execution_result") or {}).get("summary", ""),
        })
        decision = response.get("decision", "rejected")
        return {
            "human_decision": decision,
            "modify_instruction": response.get("instruction"),
            "clarification_response": None,
        }


# ============================================================
# NODE: apply_changes
# ============================================================

FIELD_ALIASES = {
    "activities": "suggested_activities",
    "suggested_activity": "suggested_activities",
    "activity": "suggested_activities",
    "assessment": "assessment_or_revision",
    "revision": "assessment_or_revision",
    "content": "planned_content",
}


def apply_changes_node(state: CurriculumAgentState, config: RunnableConfig) -> Dict[str, Any]:
    """Apply the approved proposed changes to PostgreSQL."""
    db = _get_db(config)
    if db is None:
        return {"execution_result": {"status": "error", "message": "No database session"}}

    proposed = state.get("proposed_changes", [])
    if not proposed:
        return {"execution_result": {"status": "no_changes"}}

    # Group changes by week_id for batch update
    week_updates = []
    for change in proposed:
        week_id = change.get("week_id")
        field = change.get("field")
        new_value = change.get("new_value")

        if week_id and field and new_value is not None:
            try:
                week_id = int(str(week_id).strip())
            except (ValueError, TypeError):
                continue

            normalized_field = FIELD_ALIASES.get(field.lower(), field)

            # Find existing entry or create new
            existing = next(
                (u for u in week_updates if u["week_id"] == week_id), None
            )
            if existing:
                existing["updates"][normalized_field] = new_value
            else:
                week_updates.append({
                    "week_id": week_id,
                    "updates": {normalized_field: new_value},
                })

    if week_updates:
        try:
            result = update_multiple_curriculum_weeks(
                db=db,
                user_id=state["user_id"],
                curriculum_id=state["curriculum_id"],
                week_updates=week_updates,
            )
            return {
                "execution_result": {
                    "status": "success",
                    "updated_weeks": result["count"],
                    "summary": f"Successfully updated {result['count']} weeks",
                }
            }
        except Exception as e:
            return {
                "execution_result": {"status": "error", "message": str(e)}
            }

    return {"execution_result": {"status": "no_applicable_changes"}}


# ============================================================
# NODE: save_memory
# ============================================================

def save_memory_node(state: CurriculumAgentState, config: RunnableConfig) -> Dict[str, Any]:
    """Save a concise memory of this interaction."""
    db = _get_db(config)
    if db is None:
        return {}

    decision = state.get("human_decision", "")
    result = state.get("execution_result") or {}

    if decision == "approved" and result.get("status") == "success":
        memory_type = "action"
        content = result.get("summary", "Curriculum changes applied")
    elif decision == "rejected":
        memory_type = "rejection"
        content = f"Teacher rejected proposed changes for: {state.get('user_request', '')[:100]}"
    else:
        memory_type = "action"
        content = f"Agent interaction: {state.get('user_request', '')[:100]}"

    save_memory(
        db=db,
        user_id=state["user_id"],
        curriculum_id=state["curriculum_id"],
        agent_type="curriculum",
        memory_type=memory_type,
        content=content,
    )
    return {}


# ============================================================
# ROUTING FUNCTIONS
# ============================================================

def route_after_plan(state: CurriculumAgentState) -> str:
    """Route after interpret_and_plan: clarification or approval."""
    if state.get("clarification_needed"):
        return "request_human_input"
    return "request_human_input"


def route_after_human(state: CurriculumAgentState) -> str:
    """Route after human input: apply, re-plan, or reject."""
    if state.get("clarification_response"):
        # Teacher answered a clarification — re-plan
        return "interpret_and_plan"

    decision = state.get("human_decision", "")
    if decision == "approved":
        return "apply_changes"
    elif decision == "modify":
        return "interpret_and_plan"
    else:
        # rejected
        return "save_memory"
