# chunker.py
import re
from typing import List, Dict, Any

from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter


def classify_chunk_type(text: str) -> str:
    """
    Classify a chunk as 'theory', 'toc', 'exercise', or 'answer' using
    simple heuristics. Used to filter out low-value chunks (table of
    contents, question sets, answer keys) from retrieval, so queries
    about actual subject content aren't drowned out by noise.
    """

    stripped = text.strip()

    # Very short fragments are usually leftover TOC lines or page
    # headers/footers rather than real content.
    if len(stripped) < 40:
        return "toc"

    lines = [line.strip() for line in stripped.split("\n") if line.strip()]

    if not lines:
        return "toc"

    # Table of contents: lines like "1.1 Introduction ......... 5"
    toc_line_pattern = re.compile(r"\.{3,}\s*\d+\s*$")
    toc_lines = sum(1 for line in lines if toc_line_pattern.search(line))
    if toc_lines / len(lines) > 0.3:
        return "toc"

    # Answer keys usually start with a clear heading.
    if re.match(r"^(answers?|answer\s*key)\b", stripped, re.IGNORECASE):
        return "answer"

    # Exercises/question sets usually start with a clear heading.
    if re.match(
        r"^(exercise|exercises|questions?|practice\s*questions?)\b",
        stripped,
        re.IGNORECASE,
    ):
        return "exercise"

    # Chunks dominated by question-style lines (numbered questions or
    # lines ending in "?") are treated as exercises even without a
    # heading.
    question_line_pattern = re.compile(r"^(q\.?\s*\d+|Q\d+)[\.\):]")
    question_lines = sum(
        1
        for line in lines
        if line.endswith("?") or question_line_pattern.match(line)
    )
    if question_lines / len(lines) > 0.4:
        return "exercise"

    return "theory"


def chunk_documents(
    documents: List[Document],
    metadata: Dict[str, Any],
    chunk_size: int = 1000,
    chunk_overlap: int = 150,
) -> List[Document]:
    """
    Split documents into chunks, attach curriculum metadata to every
    chunk, and tag each chunk with a content_type (theory / toc /
    exercise / answer) so retrieval can prioritize real subject
    content over index pages and question sets.
    """

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=[
            "\n\n",
            "\n",
            ". ",
            "? ",
            "! ",
            " ",
            "",
        ],
        add_start_index=True,
    )

    chunks = splitter.split_documents(documents)

    for index, chunk in enumerate(chunks):
        chunk.metadata.update(metadata)
        chunk.metadata["chunk_id"] = index
        chunk.metadata["content_type"] = classify_chunk_type(chunk.page_content)

    return chunks