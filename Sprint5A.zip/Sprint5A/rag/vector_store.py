import hashlib
from pathlib import Path
from typing import List, Optional

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_huggingface import HuggingFaceEmbeddings


CHROMA_DIR = Path("data/chroma")


def _build_chunk_id(chunk: Document) -> str:
    """
    Build a deterministic ID for a chunk so re-indexing the same
    document doesn't create duplicate entries in ChromaDB. The ID is
    based on the source file, the page number (PDFs load one Document
    per page, so start_index alone resets per page and can collide
    across pages), the chunk's start_index within that page, and the
    curriculum metadata — so indexing the same file+curriculum
    combination again overwrites the previous chunks instead of
    duplicating them.
    """

    source = chunk.metadata.get("source", "")
    page = chunk.metadata.get("page", "")
    start_index = chunk.metadata.get("start_index", chunk.metadata.get("chunk_id", ""))
    subject = chunk.metadata.get("subject", "")
    grade = chunk.metadata.get("grade", "")
    academic_year = chunk.metadata.get("academic_year", "")
    curriculum_id = chunk.metadata.get("curriculum_id", "")

    raw_id = f"{source}|{page}|{start_index}|{subject}|{grade}|{academic_year}|{curriculum_id}"

    return hashlib.sha256(raw_id.encode("utf-8")).hexdigest()


def create_vector_store(
    documents: List[Document],
    embeddings: HuggingFaceEmbeddings,
    collection_name: str = "curriculum_documents",
) -> Chroma:
    """
    Create or open a ChromaDB vector store and add documents.

    Chunks are added with deterministic IDs (see _build_chunk_id).
    Any existing entries with the same IDs are deleted first, so
    re-indexing the same document is idempotent instead of creating
    duplicate entries.
    """

    CHROMA_DIR.mkdir(parents=True, exist_ok=True)

    vector_store = Chroma(
        collection_name=collection_name,
        embedding_function=embeddings,
        persist_directory=str(CHROMA_DIR),
    )

    if documents:
        ids = [_build_chunk_id(document) for document in documents]
        vector_store.delete(ids=ids)
        vector_store.add_documents(documents, ids=ids)

    return vector_store


def get_vector_store(
    embeddings: HuggingFaceEmbeddings,
    collection_name: str = "curriculum_documents",
) -> Chroma:
    """Open an existing ChromaDB vector store."""

    CHROMA_DIR.mkdir(parents=True, exist_ok=True)

    return Chroma(
        collection_name=collection_name,
        embedding_function=embeddings,
        persist_directory=str(CHROMA_DIR),
    )


def delete_by_curriculum_id(
    embeddings: HuggingFaceEmbeddings,
    curriculum_id: str,
    collection_name: str = "curriculum_documents"
):
    """Safely delete all ChromaDB documents associated with a specific curriculum."""
    vector_store = get_vector_store(embeddings, collection_name)
    try:
        vector_store._collection.delete(where={"curriculum_id": str(curriculum_id)})
    except Exception as e:
        print(f"Error deleting from ChromaDB: {e}")


def similarity_search(
    vector_store: Chroma,
    query: str,
    k: int = 4,
    metadata_filter: Optional[dict] = None,
):
    """Retrieve relevant documents from ChromaDB."""

    if metadata_filter:
        return vector_store.similarity_search(
            query,
            k=k,
            filter=metadata_filter,
        )

    return vector_store.similarity_search(query, k=k)