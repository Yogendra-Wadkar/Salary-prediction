# retriever.py
from typing import Optional, Sequence

from langchain_chroma import Chroma


def retrieve_documents(
    vector_store: Chroma,
    query: str,
    k: int = 4,
    subject: Optional[str] = None,
    grade: Optional[str] = None,
    academic_year: Optional[str] = None,
    curriculum_id: Optional[int] = None,
    content_types: Optional[Sequence[str]] = None,
):
    """
    Retrieve relevant chunks from ChromaDB using metadata filters.

    By default only "theory" chunks are retrieved, so table-of-contents
    pages, exercises, and answer keys (tagged during indexing) don't
    crowd out real subject content. Pass content_types=None to disable
    this filter and see everything.
    """

    conditions = []

    if curriculum_id is not None:
        conditions.append({"curriculum_id": str(curriculum_id)})

    if subject:
        conditions.append({"subject": subject})

    if grade:
        conditions.append({"grade": grade})

    if academic_year:
        conditions.append({"academic_year": academic_year})

    if content_types:
        if len(content_types) == 1:
            conditions.append({"content_type": content_types[0]})
        else:
            conditions.append({"content_type": {"$in": list(content_types)}})

    if len(conditions) == 0:
        metadata_filter = None
    elif len(conditions) == 1:
        metadata_filter = conditions[0]
    else:
        metadata_filter = {"$and": conditions}

    return vector_store.similarity_search(
        query,
        k=k,
        filter=metadata_filter,
    )


def format_retrieved_documents(documents) -> str:
    """Combine retrieved document chunks into a single context string."""

    if not documents:
        return "No relevant information was found."

    return "\n\n".join(
        document.page_content
        for document in documents
    )