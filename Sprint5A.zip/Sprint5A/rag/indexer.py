from pathlib import Path
from typing import Dict, Any

from utils.document_utils import load_document
from rag.chunker import chunk_documents
from rag.embeddings import get_embedding_model
from rag.vector_store import create_vector_store


def index_document(
    file_path: str,
    metadata: Dict[str, Any],
):
    """
    Complete document indexing pipeline:
    Load → Chunk → Metadata → Embeddings → ChromaDB
    """

    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    # 1. Load PDF/DOCX
    documents = load_document(str(path))

    # 2. Split into chunks and attach metadata
    chunks = chunk_documents(
        documents=documents,
        metadata=metadata,
    )

    # 3. Load Hugging Face embedding model
    embeddings = get_embedding_model()

    # 4. Store chunks + embeddings in ChromaDB
    vector_store = create_vector_store(
        documents=chunks,
        embeddings=embeddings,
    )

    return vector_store