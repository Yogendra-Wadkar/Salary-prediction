import os
import re
from typing import Any, List, Type

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from pydantic import BaseModel


load_dotenv()


# Default model for all workflows (3.6 is deprecated)
DEFAULT_MODEL = "gemini-3.7-flash"


def get_llm(
    model: str = DEFAULT_MODEL,
    max_output_tokens: int = 8192,
    thinking_level: str = "low",
    api_key_env: str = "GOOGLE_API_KEY_CURRICULUM",
    max_retries: int = 3,
):
    """
    Create a Gemini LLM.

    api_key_env selects the workflow-specific key.
    Falls back to GOOGLE_API_KEY for backward compatibility.
    """
    # Dynamically reload .env to ensure fresh API keys without process restarts
    load_dotenv(override=True)
    api_key = os.getenv(api_key_env) or os.getenv("GOOGLE_API_KEY")

    if not api_key:
        raise ValueError(
            f"{api_key_env} is not set. "
            "Add your Gemini API key to the .env file."
        )

    return ChatGoogleGenerativeAI(
        model=model,
        google_api_key=api_key,
        max_output_tokens=max_output_tokens,
        thinking_level=thinking_level,
        max_retries=max_retries,
    )


def get_structured_llm(
    schema: Type[BaseModel],
    model: str = DEFAULT_MODEL,
    max_output_tokens: int = 16384,
    thinking_level: str = "low",
    api_key_env: str = "GOOGLE_API_KEY_CURRICULUM",
    max_retries: int = 3,
):
    """
    Create a Gemini model that returns structured output
    according to the provided Pydantic schema.
    """

    llm = get_llm(
        model=model,
        max_output_tokens=max_output_tokens,
        thinking_level=thinking_level,
        api_key_env=api_key_env,
        max_retries=max_retries,
    )

    return llm.with_structured_output(
        schema,
        method="json_schema",
    )


def build_rag_context(
    documents: List[Document],
) -> str:
    """
    Convert retrieved documents into LLM context.
    """

    if not documents:
        return "No relevant curriculum information was found."

    return "\n\n".join(
        (
            f"[Page {document.metadata.get('page', 'unknown')} | "
            f"Type: {document.metadata.get('content_type', 'unknown')}]\n"
            f"{document.page_content}"
        )
        for document in documents
    )


def create_rag_prompt() -> ChatPromptTemplate:
    """
    Create the prompt used by the RAG chatbot.
    """

    return ChatPromptTemplate.from_messages(
        [
            (
                "system",
                """
You are an AI-powered educational curriculum assistant.

Use ONLY the information provided in the context.
Do not invent facts or use unsupported information.

Give clear, accurate, teacher-friendly answers.

Answer in simple, natural human language.

If the answer is not available in the provided context,
say:

"I could not find this information in the provided curriculum."

Context:
{context}
""",
            ),
            (
                "human",
                "{question}",
            ),
        ]
    )


def create_rag_chain():
    """
    Create the normal RAG chain.

    The chatbot uses Gemini 3.7 Flash with Key 2.
    """

    llm = get_llm(
        model=DEFAULT_MODEL,
        max_output_tokens=8192,
        thinking_level="low",
        api_key_env="GOOGLE_API_KEY_AI_ASSISTANT",
    )

    prompt = create_rag_prompt()

    return prompt | llm


def _clean_response_content(content: Any) -> str:
    """
    Convert Gemini response content to plain text while preserving markdown and LaTeX.
    """

    if isinstance(content, str):
        text = content

    elif isinstance(content, list):
        parts = []

        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and item.get("text"):
                parts.append(str(item["text"]))

        text = "\n".join(parts)

    else:
        text = str(content)

    return text.strip()


def generate_rag_response(
    documents: List[Document],
    question: str,
) -> str:
    """
    Generate an answer using retrieved curriculum context.
    """

    context = build_rag_context(
        documents
    )

    rag_chain = create_rag_chain()

    response = rag_chain.invoke(
        {
            "context": context,
            "question": question,
        }
    )

    return _clean_response_content(
        response.content
    )