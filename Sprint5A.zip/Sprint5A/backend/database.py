import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv

load_dotenv()

SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL")

if not SQLALCHEMY_DATABASE_URL:
    raise RuntimeError("DATABASE_URL is not configured in the .env file.")

engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def run_safe_migrations():
    """
    Add new columns/tables to existing schema without dropping data.
    All statements are idempotent (IF NOT EXISTS).
    """
    migrations = [
        # Phase 1 column migrations
        "ALTER TABLE curriculums ADD COLUMN IF NOT EXISTS teacher_name VARCHAR",
        "ALTER TABLE curriculums ADD COLUMN IF NOT EXISTS workflow_type VARCHAR DEFAULT 'new'",
        "ALTER TABLE curriculums ADD COLUMN IF NOT EXISTS alignment_review JSONB",

        # Phase 2 — Agent Memory
        """CREATE TABLE IF NOT EXISTS agent_memory (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            curriculum_id INTEGER NOT NULL REFERENCES curriculums(id) ON DELETE CASCADE,
            agent_type VARCHAR(50) NOT NULL,
            memory_type VARCHAR(50) NOT NULL,
            content TEXT NOT NULL,
            metadata JSONB DEFAULT '{}',
            created_at TIMESTAMPTZ DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS idx_agent_memory_scope ON agent_memory(user_id, curriculum_id, agent_type)",

        # Phase 2 — Assessment Batches
        """CREATE TABLE IF NOT EXISTS assessment_batches (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            curriculum_id INTEGER NOT NULL REFERENCES curriculums(id) ON DELETE CASCADE,
            assessment_type VARCHAR(100) NOT NULL,
            portion VARCHAR(255) NOT NULL,
            total_questions INTEGER NOT NULL,
            difficulty_distribution JSONB NOT NULL,
            question_type_distribution JSONB NOT NULL,
            variation_count INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )""",

        # Phase 2 — Assessment Versions
        """CREATE TABLE IF NOT EXISTS assessments (
            id SERIAL PRIMARY KEY,
            batch_id INTEGER NOT NULL REFERENCES assessment_batches(id) ON DELETE CASCADE,
            curriculum_id INTEGER NOT NULL REFERENCES curriculums(id) ON DELETE CASCADE,
            variation_number INTEGER NOT NULL,
            questions JSONB NOT NULL,
            validation_status VARCHAR(50) NOT NULL DEFAULT 'pending',
            created_at TIMESTAMPTZ DEFAULT NOW()
        )""",
    ]
    with engine.begin() as conn:
        for sql in migrations:
            conn.execute(text(sql))

