from pydantic import BaseModel, EmailStr
from typing import Optional, List, Any, Dict
from datetime import datetime

class UserBase(BaseModel):
    username: str
    email: EmailStr

class UserCreate(UserBase):
    password: str

class UserResponse(UserBase):
    id: int
    is_active: bool

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

class CurriculumWeekBase(BaseModel):
    year: str
    month: str
    week: str
    unit: str
    topic: str
    planned_content: str
    suggested_activities: str
    assessment_or_revision: str
    status: str

class CurriculumWeekResponse(CurriculumWeekBase):
    id: int
    order_index: int
    
    class Config:
        from_attributes = True

class CurriculumWeekUpdate(BaseModel):
    year: Optional[str] = None
    month: Optional[str] = None
    week: Optional[str] = None
    unit: Optional[str] = None
    topic: Optional[str] = None
    planned_content: Optional[str] = None
    suggested_activities: Optional[str] = None
    assessment_or_revision: Optional[str] = None
    status: Optional[str] = None

class CurriculumBase(BaseModel):
    subject: str
    grade: str
    academic_year: str
    teacher_name: Optional[str] = None
    start_month: Optional[str] = None
    end_month: Optional[str] = None
    total_teaching_days: Optional[str] = None
    weekly_teaching_hours: Optional[str] = None
    assessment_frequency: Optional[str] = None
    midterm_exam_month: Optional[str] = None
    final_exam_month: Optional[str] = None

class CurriculumCreate(CurriculumBase):
    structured_syllabus: Optional[Any] = None
    weeks: List[CurriculumWeekBase] = []

class CurriculumResponse(CurriculumBase):
    id: int
    user_id: int
    workflow_type: Optional[str] = "new"
    alignment_review: Optional[Any] = None
    created_at: datetime
    weeks: List[CurriculumWeekResponse] = []

    class Config:
        from_attributes = True

class CurriculumSummaryResponse(CurriculumBase):
    id: int
    user_id: int
    workflow_type: Optional[str] = "new"
    created_at: datetime

    class Config:
        from_attributes = True

class GenerateCurriculumRequest(BaseModel):
    teacher_name: str
    subject: str
    grade: str
    academic_year: str
    start_month: str
    end_month: str
    total_teaching_days: str
    weekly_teaching_hours: str
    assessment_frequency: str
    midterm_exam_month: str
    final_exam_month: str

class AssessmentGenerateRequest(BaseModel):
    curriculum_id: int
    assessment_type: str
    num_questions: int
    portion: str
    difficulty_distribution: Dict[str, int]
    question_type_distribution: Dict[str, int]

class ReplacementQuestionRequest(BaseModel):
    curriculum_id: int
    assessment_period: str
    question_type: str
    difficulty: str
    question: str

class ChatRequest(BaseModel):
    curriculum_id: int
    question: str


# ============================================================
# PHASE 2 — AGENT SCHEMAS
# ============================================================

class CurriculumAgentRequest(BaseModel):
    curriculum_id: int
    instruction: str

class CurriculumAgentResumeRequest(BaseModel):
    decision: str                       # "approved" | "rejected" | "modify"
    instruction: Optional[str] = None   # Only when decision == "modify"
    response: Optional[str] = None      # Only for clarification responses

class AssessmentAgentRequest(BaseModel):
    curriculum_id: int
    assessment_type: str
    portion: str
    num_questions: int
    difficulty_distribution: Dict[str, int]
    question_type_distribution: Dict[str, int]
    variation_count: int = 2
