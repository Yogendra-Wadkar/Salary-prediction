from sqlalchemy import Column, Integer, String, ForeignKey, Boolean, JSON, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)

    curriculums = relationship("Curriculum", back_populates="user")


class Curriculum(Base):
    __tablename__ = "curriculums"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    teacher_name = Column(String, nullable=True)
    workflow_type = Column(String, default="new")  # "new" or "enhancement"
    subject = Column(String, nullable=False)
    grade = Column(String, nullable=False)
    academic_year = Column(String, nullable=False)
    
    start_month = Column(String)
    end_month = Column(String)
    total_teaching_days = Column(String)
    weekly_teaching_hours = Column(String)
    assessment_frequency = Column(String)
    midterm_exam_month = Column(String)
    final_exam_month = Column(String)
    
    structured_syllabus = Column(JSON, nullable=True)
    alignment_review = Column(JSON, nullable=True)  # For enhancement workflow

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="curriculums")
    weeks = relationship("CurriculumWeek", back_populates="curriculum", cascade="all, delete-orphan", order_by="CurriculumWeek.order_index")


class CurriculumWeek(Base):
    __tablename__ = "curriculum_weeks"

    id = Column(Integer, primary_key=True, index=True)
    curriculum_id = Column(Integer, ForeignKey("curriculums.id"))
    
    order_index = Column(Integer)
    year = Column(String)
    month = Column(String)
    week = Column(String)
    unit = Column(String)
    topic = Column(String)
    planned_content = Column(String)
    suggested_activities = Column(String)
    assessment_or_revision = Column(String)
    status = Column(String, default="Pending")

    curriculum = relationship("Curriculum", back_populates="weeks")


# ============================================================
# PHASE 2 — AGENT MEMORY
# ============================================================

class AgentMemory(Base):
    __tablename__ = "agent_memory"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    curriculum_id = Column(Integer, ForeignKey("curriculums.id"), nullable=False)
    agent_type = Column(String(50), nullable=False)       # 'curriculum' | 'assessment'
    memory_type = Column(String(50), nullable=False)       # 'action' | 'preference' | 'rejection'
    content = Column(String, nullable=False)
    metadata_ = Column("metadata", JSON, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


# ============================================================
# PHASE 2 — ASSESSMENT STORAGE
# ============================================================

class AssessmentBatch(Base):
    __tablename__ = "assessment_batches"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    curriculum_id = Column(Integer, ForeignKey("curriculums.id"), nullable=False)
    assessment_type = Column(String(100), nullable=False)
    portion = Column(String(255), nullable=False)
    total_questions = Column(Integer, nullable=False)
    difficulty_distribution = Column(JSON, nullable=False)
    question_type_distribution = Column(JSON, nullable=False)
    variation_count = Column(Integer, nullable=False, default=1)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    assessments = relationship(
        "Assessment", back_populates="batch", cascade="all, delete-orphan"
    )


class Assessment(Base):
    __tablename__ = "assessments"

    id = Column(Integer, primary_key=True, index=True)
    batch_id = Column(Integer, ForeignKey("assessment_batches.id"), nullable=False)
    curriculum_id = Column(Integer, ForeignKey("curriculums.id"), nullable=False)
    variation_number = Column(Integer, nullable=False)
    questions = Column(JSON, nullable=False)
    validation_status = Column(String(50), nullable=False, default="pending")  # 'valid' | 'failed'
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    batch = relationship("AssessmentBatch", back_populates="assessments")
