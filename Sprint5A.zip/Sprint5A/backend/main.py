import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.database import engine, Base, run_safe_migrations
from backend.routers import auth, curriculum, dashboard, assessment, chat, files
from backend.routers import agents as agents_router


# ============================================================
# LANGGRAPH CHECKPOINTER — APPLICATION-WIDE SINGLETON
# ============================================================

_checkpointer = None


def get_checkpointer():
    """Access the application-wide LangGraph PostgreSQL checkpointer."""
    if _checkpointer is None:
        raise RuntimeError("Checkpointer not initialized — app not started?")
    return _checkpointer


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    FastAPI lifespan: initialize and clean up the LangGraph
    PostgreSQL checkpointer at startup/shutdown.
    """
    global _checkpointer

    # Create database tables + run safe migrations
    Base.metadata.create_all(bind=engine)
    run_safe_migrations()

    # Initialize LangGraph PostgreSQL checkpointer
    conn_string = os.getenv("LANGGRAPH_CHECKPOINT_DATABASE_URL")
    if conn_string:
        from typing import cast, Any
        from langgraph.checkpoint.postgres import PostgresSaver
        import psycopg

        # Create a persistent connection for the checkpointer (PostgresSaver requires autocommit=True)
        _conn = psycopg.connect(conn_string, autocommit=True)
        _checkpointer = PostgresSaver(conn=cast(Any, _conn))
        _checkpointer.setup()  # Idempotent: creates checkpoint tables if missing
        print("[Phase 2] LangGraph PostgreSQL checkpointer initialized")
    else:
        _conn = None
        print("[Phase 2] WARNING: LANGGRAPH_CHECKPOINT_DATABASE_URL not set — agents will not work")

    yield  # Application runs

    # Cleanup
    _checkpointer = None
    if _conn:
        _conn.close()


# ============================================================
# APPLICATION
# ============================================================

app = FastAPI(title="TeacherOS API", lifespan=lifespan)

# Add CORS middleware to allow the frontend to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For prototyping
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Phase 1 routers (preserved)
app.include_router(auth.router)
app.include_router(curriculum.router)
app.include_router(dashboard.router)
app.include_router(assessment.router)  # Legacy assessment — kept during transition
app.include_router(chat.router)
app.include_router(files.router)

# Phase 2 agent routers
app.include_router(agents_router.router)


class NoCacheStaticFiles(StaticFiles):
    def is_not_modified(self, response_headers, request_headers) -> bool:
        return False

    def file_response(self, *args, **kwargs):
        resp = super().file_response(*args, **kwargs)
        resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"] = "no-cache"
        resp.headers["Expires"] = "0"
        return resp


# Mount the static frontend with disabled caching
app.mount("/", NoCacheStaticFiles(directory="frontend", html=True), name="frontend")
