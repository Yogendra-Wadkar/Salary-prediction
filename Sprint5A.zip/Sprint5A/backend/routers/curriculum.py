import os
import shutil
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from typing import List, Optional
import json
import io

from backend.database import get_db
from backend.models import User, Curriculum, CurriculumWeek
from backend.auth import get_current_user
from backend.schemas import (
    CurriculumCreate, CurriculumResponse, CurriculumSummaryResponse, 
    CurriculumWeekUpdate, CurriculumWeekResponse, GenerateCurriculumRequest
)
from orchestrator import generate_curriculum, analyze_and_improve
from rag.indexer import index_document
from rag.embeddings import get_embedding_model
from rag.vector_store import delete_by_curriculum_id
import glob

router = APIRouter(prefix="/curriculums", tags=["curriculums"])

UPLOAD_DIR = "data/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)


def _safe_filename(filename: str) -> str:
    """Sanitize filename to prevent directory traversal."""
    return os.path.basename(filename).replace("..", "").replace("/", "").replace("\\", "")


def _save_upload(file: UploadFile, curriculum_id: int, prefix: str) -> str:
    """Save an uploaded file safely and return the path."""
    safe_name = _safe_filename(file.filename)
    file_path = os.path.join(UPLOAD_DIR, f"curr_{curriculum_id}_{prefix}_{safe_name}")
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return file_path


def _save_weeks_to_db(db: Session, curriculum_id: int, weeks_data: list):
    """Clear existing weeks and save new ones."""
    db.query(CurriculumWeek).filter(CurriculumWeek.curriculum_id == curriculum_id).delete()
    for idx, week_data in enumerate(weeks_data):
        db_week = CurriculumWeek(
            curriculum_id=curriculum_id,
            order_index=idx,
            year=str(week_data.get("year", "")),
            month=str(week_data.get("month", "")),
            week=str(week_data.get("week", "")),
            unit=str(week_data.get("unit", "")),
            topic=str(week_data.get("topic", "")),
            planned_content=str(week_data.get("planned_content", "")),
            suggested_activities=str(week_data.get("suggested_activities", "")),
            assessment_or_revision=str(week_data.get("assessment_or_revision", "")),
            status=str(week_data.get("status", "Pending"))
        )
        db.add(db_week)


# ============================================================
# CREATE CURRICULUM (manual, no generation)
# ============================================================

@router.post("", response_model=CurriculumResponse)
def create_curriculum(curriculum: CurriculumCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db_curriculum = Curriculum(
        user_id=current_user.id,
        teacher_name=curriculum.teacher_name,
        subject=curriculum.subject,
        grade=curriculum.grade,
        academic_year=curriculum.academic_year,
        start_month=curriculum.start_month,
        end_month=curriculum.end_month,
        total_teaching_days=curriculum.total_teaching_days,
        weekly_teaching_hours=curriculum.weekly_teaching_hours,
        assessment_frequency=curriculum.assessment_frequency,
        midterm_exam_month=curriculum.midterm_exam_month,
        final_exam_month=curriculum.final_exam_month,
        structured_syllabus=curriculum.structured_syllabus
    )
    db.add(db_curriculum)
    db.commit()
    db.refresh(db_curriculum)
    return db_curriculum


# ============================================================
# LIST / GET CURRICULA
# ============================================================

@router.get("", response_model=List[CurriculumSummaryResponse])
def get_curriculums(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(Curriculum).filter(Curriculum.user_id == current_user.id).all()

@router.get("/{curriculum_id}", response_model=CurriculumResponse)
def get_curriculum(curriculum_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    curriculum = db.query(Curriculum).filter(Curriculum.id == curriculum_id, Curriculum.user_id == current_user.id).first()
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found")
    return curriculum

@router.get("/{curriculum_id}/weeks", response_model=List[CurriculumWeekResponse])
def get_curriculum_weeks_endpoint(curriculum_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    curriculum = db.query(Curriculum).filter(Curriculum.id == curriculum_id, Curriculum.user_id == current_user.id).first()
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found")
    weeks = db.query(CurriculumWeek).filter(CurriculumWeek.curriculum_id == curriculum_id).order_by(CurriculumWeek.order_index).all()
    return weeks



# ============================================================
# UNIFIED NEW CURRICULUM GENERATION (single request)
# ============================================================

@router.post("/generate", response_model=CurriculumResponse)
async def generate_curriculum_unified(
    teacher_name: str = Form(...),
    subject: str = Form(...),
    grade: str = Form(...),
    academic_year: str = Form(...),
    start_month: str = Form(...),
    end_month: str = Form(...),
    total_teaching_days: str = Form(...),
    weekly_teaching_hours: str = Form(...),
    assessment_frequency: str = Form(...),
    midterm_exam_month: str = Form(...),
    final_exam_month: str = Form(...),
    syllabus_file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Unified new curriculum generation:
    1. Create curriculum record
    2. Save syllabus file
    3. Index syllabus into ChromaDB (exactly once)
    4. Run Stage A + Stage B curriculum generation
    5. Save generated weeks to PostgreSQL
    6. Return the complete curriculum
    """
    # Validate file type
    ext = syllabus_file.filename.split(".")[-1].lower()
    if ext not in ["pdf", "docx"]:
        raise HTTPException(status_code=400, detail="Only PDF and DOCX syllabus files are supported")

    print("=" * 60)
    print("TEACHEROS CURRICULUM GENERATION")
    print("=" * 60)

    # 1. Create curriculum record
    db_curriculum = Curriculum(
        user_id=current_user.id,
        teacher_name=teacher_name,
        workflow_type="new",
        subject=subject,
        grade=grade,
        academic_year=academic_year,
        start_month=start_month,
        end_month=end_month,
        total_teaching_days=total_teaching_days,
        weekly_teaching_hours=weekly_teaching_hours,
        assessment_frequency=assessment_frequency,
        midterm_exam_month=midterm_exam_month,
        final_exam_month=final_exam_month,
    )
    db.add(db_curriculum)
    db.commit()
    db.refresh(db_curriculum)

    curriculum_id = db_curriculum.id
    print(f"Curriculum ID: {curriculum_id}")

    # 2. Save syllabus file
    print("[1/4] Saving syllabus file")
    file_path = _save_upload(syllabus_file, curriculum_id, "syllabus")

    # 3. Index syllabus into ChromaDB (exactly once)
    print("[2/4] Indexing syllabus into ChromaDB")
    metadata = {
        "subject": subject,
        "grade": grade,
        "academic_year": academic_year,
        "document_type": "syllabus",
        "curriculum_id": str(curriculum_id)
    }
    try:
        index_document(file_path=file_path, metadata=metadata)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to index syllabus: {str(e)}")

    # 4. Run curriculum generation (Stage A + Stage B)
    print("[3/4] Running AI curriculum generation")
    try:
        generated = generate_curriculum(
            teacher_name=teacher_name,
            subject=subject,
            grade=grade,
            academic_year=academic_year,
            start_month=start_month,
            end_month=end_month,
            total_teaching_days=total_teaching_days,
            weekly_teaching_hours=weekly_teaching_hours,
            assessment_frequency=assessment_frequency,
            midterm_month=midterm_exam_month,
            final_month=final_exam_month,
            curriculum_id=str(curriculum_id)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    # 5. Save generated weeks
    print("[4/4] Saving curriculum")
    weeks = generated.get("curriculum", [])
    _save_weeks_to_db(db, curriculum_id, weeks)
    db_curriculum.structured_syllabus = generated.get("unscheduled_or_flagged_items", [])
    db.commit()
    db.refresh(db_curriculum)

    print(f"[DONE] Curriculum generated successfully — {len(weeks)} weeks created")
    print("=" * 60)

    return db_curriculum


# ============================================================
# UNIFIED EXISTING CURRICULUM ENHANCEMENT (single request)
# ============================================================

@router.post("/enhance", response_model=CurriculumResponse)
async def enhance_curriculum_unified(
    teacher_name: str = Form(...),
    subject: str = Form(...),
    grade: str = Form(...),
    academic_year: str = Form(...),
    start_month: str = Form(...),
    end_month: str = Form(...),
    total_teaching_days: str = Form(...),
    weekly_teaching_hours: str = Form(...),
    assessment_frequency: str = Form(...),
    midterm_exam_month: str = Form(...),
    final_exam_month: str = Form(...),
    syllabus_file: UploadFile = File(...),
    existing_file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Unified existing curriculum enhancement:
    1. Create curriculum record
    2. Save both files
    3. Index syllabus into ChromaDB (once)
    4. Load existing curriculum
    5. Run analyze_and_improve()
    6. Save improved weeks to PostgreSQL
    7. Return curriculum with alignment review
    """
    # Validate file types
    syllabus_ext = syllabus_file.filename.split(".")[-1].lower()
    if syllabus_ext not in ["pdf", "docx"]:
        raise HTTPException(status_code=400, detail="Syllabus must be PDF or DOCX")

    existing_ext = existing_file.filename.split(".")[-1].lower()
    if existing_ext not in ["pdf", "docx", "xlsx"]:
        raise HTTPException(status_code=400, detail="Existing curriculum must be PDF, DOCX, or XLSX")

    print("=" * 60)
    print("TEACHEROS CURRICULUM ENHANCEMENT")
    print("=" * 60)

    # 1. Create curriculum record
    db_curriculum = Curriculum(
        user_id=current_user.id,
        teacher_name=teacher_name,
        workflow_type="enhancement",
        subject=subject,
        grade=grade,
        academic_year=academic_year,
        start_month=start_month,
        end_month=end_month,
        total_teaching_days=total_teaching_days,
        weekly_teaching_hours=weekly_teaching_hours,
        assessment_frequency=assessment_frequency,
        midterm_exam_month=midterm_exam_month,
        final_exam_month=final_exam_month,
    )
    db.add(db_curriculum)
    db.commit()
    db.refresh(db_curriculum)

    curriculum_id = db_curriculum.id
    print(f"Curriculum ID: {curriculum_id}")

    # 2. Save files
    print("[1/5] Saving files")
    syllabus_path = _save_upload(syllabus_file, curriculum_id, "syllabus")
    existing_path = _save_upload(existing_file, curriculum_id, "existing")

    # 3. Run analyze_and_improve (indexes syllabus internally, once)
    print("[2/5] Indexing syllabus")
    print("[3/5] Analyzing existing curriculum")
    print("[4/5] Generating improved curriculum")

    form_data = {
        "teacher_name": teacher_name,
        "subject": subject,
        "grade": grade,
        "academic_year": academic_year,
        "start_month": start_month,
        "end_month": end_month,
        "total_teaching_days": total_teaching_days,
        "weekly_teaching_hours": weekly_teaching_hours,
        "assessment_frequency": assessment_frequency,
        "midterm_exam_month": midterm_exam_month,
        "final_exam_month": final_exam_month,
    }

    try:
        result = analyze_and_improve(
            form_data=form_data,
            existing_plan_path=existing_path,
            syllabus_path=syllabus_path,
            curriculum_id=str(curriculum_id)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    # 4. Save improved weeks
    print("[5/5] Saving improved curriculum")
    improved = result.get("improved_curriculum", {})
    weeks = improved.get("curriculum", [])
    _save_weeks_to_db(db, curriculum_id, weeks)

    db_curriculum.alignment_review = result.get("alignment_review", {})
    db_curriculum.structured_syllabus = improved.get("unscheduled_or_flagged_items", [])
    db.commit()
    db.refresh(db_curriculum)

    print(f"[DONE] Curriculum enhanced successfully — {len(weeks)} weeks created")
    print("=" * 60)

    return db_curriculum


# ============================================================
# LEGACY GENERATE ENDPOINT (backward compatibility)
# ============================================================

@router.post("/{curriculum_id}/generate", response_model=CurriculumResponse)
def generate_curriculum_legacy(curriculum_id: int, request: GenerateCurriculumRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    curriculum = db.query(Curriculum).filter(Curriculum.id == curriculum_id, Curriculum.user_id == current_user.id).first()
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found")
        
    try:
        generated = generate_curriculum(
            teacher_name=request.teacher_name,
            subject=request.subject,
            grade=request.grade,
            academic_year=request.academic_year,
            start_month=request.start_month,
            end_month=request.end_month,
            total_teaching_days=request.total_teaching_days,
            weekly_teaching_hours=request.weekly_teaching_hours,
            assessment_frequency=request.assessment_frequency,
            midterm_month=request.midterm_exam_month,
            final_month=request.final_exam_month,
            curriculum_id=str(curriculum.id)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
        
    weeks = generated.get("curriculum", [])
    _save_weeks_to_db(db, curriculum_id, weeks)
    curriculum.structured_syllabus = generated.get("unscheduled_or_flagged_items", [])
    
    db.commit()
    db.refresh(curriculum)
    return curriculum


# ============================================================
# UPDATE WEEK
# ============================================================

@router.put("/{curriculum_id}/weeks/{week_id}", response_model=CurriculumWeekResponse)
def update_curriculum_week(curriculum_id: int, week_id: int, week_update: CurriculumWeekUpdate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    curriculum = db.query(Curriculum).filter(Curriculum.id == curriculum_id, Curriculum.user_id == current_user.id).first()
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found")
        
    db_week = db.query(CurriculumWeek).filter(CurriculumWeek.id == week_id, CurriculumWeek.curriculum_id == curriculum_id).first()
    if not db_week:
        raise HTTPException(status_code=404, detail="Curriculum week not found")
        
    update_data = week_update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_week, key, value)
        
    db.commit()
    db.refresh(db_week)
    return db_week


# ============================================================
# EXPORT CURRICULUM TO EXCEL
# ============================================================

@router.get("/{curriculum_id}/export")
def export_curriculum(curriculum_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    curriculum = db.query(Curriculum).filter(Curriculum.id == curriculum_id, Curriculum.user_id == current_user.id).first()
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found")

    try:
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = f"{curriculum.subject} - Grade {curriculum.grade}"

        # Header
        headers = ["Month", "Week", "Unit/Chapter", "Topic", "Planned Content", "Suggested Activities", "Assessment/Revision", "Status"]
        ws.append(headers)

        # Style header
        for cell in ws[1]:
            cell.font = openpyxl.styles.Font(bold=True, color="FFFFFF")
            cell.fill = openpyxl.styles.PatternFill(start_color="0F1B3D", end_color="0F1B3D", fill_type="solid")

        # Data rows
        weeks = db.query(CurriculumWeek).filter(CurriculumWeek.curriculum_id == curriculum_id).order_by(CurriculumWeek.order_index).all()
        for w in weeks:
            ws.append([w.month, w.week, w.unit, w.topic, w.planned_content, w.suggested_activities, w.assessment_or_revision, w.status])

        # Auto-fit column widths
        for col in ws.columns:
            max_length = max(len(str(cell.value or "")) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_length + 2, 40)

        buffer = io.BytesIO()
        wb.save(buffer)
        buffer.seek(0)

        filename = f"{curriculum.subject}_Grade{curriculum.grade}_Curriculum.xlsx"
        return StreamingResponse(
            buffer,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")


# ============================================================
# DELETE CURRICULUM
# ============================================================

@router.delete("/{curriculum_id}")
def delete_curriculum(curriculum_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    curriculum = db.query(Curriculum).filter(Curriculum.id == curriculum_id, Curriculum.user_id == current_user.id).first()
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found or unauthorized")
        
    try:
        # 1. Delete associated weeks
        db.query(CurriculumWeek).filter(CurriculumWeek.curriculum_id == curriculum_id).delete()
        
        # 2. Delete the curriculum record
        db.delete(curriculum)
        db.commit()
        
        # 3. Purge from ChromaDB
        embeddings = get_embedding_model()
        delete_by_curriculum_id(embeddings, str(curriculum_id))
        
        # 4. Remove uploaded files matching this curriculum
        pattern = os.path.join(UPLOAD_DIR, f"curr_{curriculum_id}_*")
        for f in glob.glob(pattern):
            try:
                os.remove(f)
            except Exception as e:
                print(f"Warning: Failed to delete file {f}: {e}")
                
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to delete curriculum: {str(e)}")
        
    return {"status": "success", "message": "Curriculum deleted successfully"}
