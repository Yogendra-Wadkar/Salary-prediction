import os
import shutil
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from backend.database import get_db
from backend.models import User, Curriculum
from backend.auth import get_current_user
from rag.indexer import index_document

router = APIRouter(prefix="/files", tags=["files"])

UPLOAD_DIR = "data/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/upload")
async def upload_syllabus(
    curriculum_id: int = Form(...),
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    curriculum = db.query(Curriculum).filter(Curriculum.id == curriculum_id, Curriculum.user_id == current_user.id).first()
    
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found or unauthorized")
        
    ext = file.filename.split(".")[-1].lower()
    if ext not in ["pdf", "docx"]:
        raise HTTPException(status_code=400, detail="Only PDF and DOCX files are supported")
        
    file_path = os.path.join(UPLOAD_DIR, f"curr_{curriculum_id}_{file.filename}")
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    # Trigger RAG Indexing
    metadata = {
        "subject": curriculum.subject,
        "grade": curriculum.grade,
        "academic_year": curriculum.academic_year,
        "document_type": "syllabus",
        "curriculum_id": str(curriculum.id)
    }
    
    try:
        index_document(file_path=file_path, metadata=metadata)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to index document: {str(e)}")
        
    return {"message": "File uploaded and indexed successfully", "filename": file.filename}
