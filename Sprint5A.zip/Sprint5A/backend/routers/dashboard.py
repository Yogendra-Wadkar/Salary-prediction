from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend.auth import get_current_user
from backend.database import get_db
from backend.models import User, Curriculum, CurriculumWeek

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

@router.get("/{curriculum_id}")
def get_dashboard_stats(curriculum_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    curriculum = db.query(Curriculum).filter(Curriculum.id == curriculum_id, Curriculum.user_id == current_user.id).first()
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found")
        
    weeks = db.query(CurriculumWeek).filter(CurriculumWeek.curriculum_id == curriculum_id).all()
    
    weeks_sorted = sorted(weeks, key=lambda w: w.order_index)
    
    total_weeks = len(weeks)
    completed = sum(1 for w in weeks if w.status == "Completed")
    in_progress = sum(1 for w in weeks if w.status == "In Progress")
    not_completed = sum(1 for w in weeks if w.status == "Not Completed")
    pending = total_weeks - completed - in_progress - not_completed
    
    progress_percentage = (completed / total_weeks * 100) if total_weeks > 0 else 0
    
    # Calculate next topic
    next_topic = "None"
    for w in weeks_sorted:
        if w.status in ["Pending", "In Progress"] and w.topic and w.topic.strip():
            next_topic = f"Week {w.week}: {w.topic}"
            break

    # Calculate next assessment
    next_assessment = "None"
    for w in weeks_sorted:
        if w.status != "Completed" and w.assessment_or_revision and w.assessment_or_revision.strip().lower() != "none":
            next_assessment = f"Week {w.week}: {w.assessment_or_revision}"
            break

    # Calculate chapter progress
    chapters_progress = {}
    for w in weeks_sorted:
        ch = w.unit.strip() if w.unit else "General"
        if not ch: ch = "General"
        if ch not in chapters_progress:
            chapters_progress[ch] = {"total": 0, "completed": 0}
        chapters_progress[ch]["total"] += 1
        if w.status == "Completed":
            chapters_progress[ch]["completed"] += 1
    
    return {
        "curriculum_id": curriculum.id,
        "subject": curriculum.subject,
        "grade": curriculum.grade,
        "total_weeks": total_weeks,
        "completed_weeks": completed,
        "in_progress_weeks": in_progress,
        "not_completed_weeks": not_completed,
        "pending_weeks": pending,
        "progress_percentage": round(progress_percentage, 2),
        "midterm_exam_month": curriculum.midterm_exam_month,
        "final_exam_month": curriculum.final_exam_month,
        "next_topic": next_topic,
        "next_assessment": next_assessment,
        "chapters_progress": chapters_progress
    }
