"""
TeacherOS Phase 2 — Agent API Endpoints

Curriculum Agent: POST /agents/curriculum/run, resume, status
Assessment Agent: POST /agents/assessment/generate, GET batches, versions
"""

import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from langchain_core.runnables import RunnableConfig

from backend.database import get_db
from backend.models import User
from backend.auth import get_current_user
from backend.schemas import (
    CurriculumAgentRequest,
    CurriculumAgentResumeRequest,
    AssessmentAgentRequest,
)
from agents.state import CurriculumAgentState, AssessmentAgentState
from agents.tools import (
    verify_curriculum_ownership,
    get_assessment_batches,
    get_assessment,
    get_batch_with_assessments,
    delete_assessment_batch,
)

router = APIRouter(prefix="/agents", tags=["agents"])


# ============================================================
# CURRICULUM AGENT ENDPOINTS
# ============================================================

@router.post("/curriculum/run")
def curriculum_agent_run(
    request: CurriculumAgentRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    user_id: int = getattr(current_user, "id")
    # Verify ownership
    verify_curriculum_ownership(db, user_id, request.curriculum_id)

    # Generate unique thread ID
    thread_id = f"curriculum-{user_id}-{request.curriculum_id}-{uuid.uuid4().hex[:8]}"

    # Get checkpointer
    from backend.main import get_checkpointer
    try:
        checkpointer = get_checkpointer()
    except RuntimeError:
        raise HTTPException(status_code=503, detail="Agent system not initialized")

    # Build and compile graph
    from agents.graph import get_compiled_curriculum_graph
    graph = get_compiled_curriculum_graph(checkpointer=checkpointer)

    # Initial state
    initial_state: CurriculumAgentState = {
        "user_id": user_id,
        "curriculum_id": request.curriculum_id,
        "thread_id": thread_id,
        "user_request": request.instruction,
        "curriculum_data": None,
        "syllabus_context": None,
        "memory_context": None,
        "proposed_changes": None,
        "clarification_needed": None,
        "clarification_response": None,
        "human_decision": None,
        "modify_instruction": None,
        "execution_result": None,
    }

    config: RunnableConfig = {
        "configurable": {"thread_id": thread_id, "db": db},
    }

    try:
        # Run the graph — it will interrupt at HITL points
        result = graph.invoke(initial_state, config=config)

        # Check if the graph is waiting for human input
        graph_state = graph.get_state(config)
        is_interrupted = bool(graph_state.next)

        if is_interrupted:
            # Graph paused at interrupt — extract the interrupt value
            tasks = graph_state.tasks or []
            interrupt_data = None
            for task in tasks:
                if hasattr(task, 'interrupts') and task.interrupts:
                    interrupt_data = task.interrupts[0].value
                    break

            state_values = graph_state.values or {}
            proposed_changes = (
                state_values.get("proposed_changes")
                or (result.get("proposed_changes") if isinstance(result, dict) else None)
                or (interrupt_data.get("proposed_changes") if isinstance(interrupt_data, dict) else None)
            )
            clarification_needed = (
                state_values.get("clarification_needed")
                or (result.get("clarification_needed") if isinstance(result, dict) else None)
                or (interrupt_data.get("question") if isinstance(interrupt_data, dict) and interrupt_data.get("type") == "clarification" else None)
            )
            exec_res = (
                state_values.get("execution_result")
                or (result.get("execution_result") if isinstance(result, dict) else None)
                or ({"summary": interrupt_data.get("summary")} if isinstance(interrupt_data, dict) and interrupt_data.get("summary") else None)
            )

            return {
                "thread_id": thread_id,
                "status": "awaiting_input",
                "interrupt": interrupt_data,
                "proposed_changes": proposed_changes,
                "clarification_needed": clarification_needed,
                "execution_result": exec_res,
            }

        state_values = graph_state.values or {}
        exec_res = (
            (result.get("execution_result") if isinstance(result, dict) else None)
            or state_values.get("execution_result")
        )
        return {
            "thread_id": thread_id,
            "status": "completed",
            "execution_result": exec_res,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Agent error: {str(e)}")


@router.post("/curriculum/{thread_id}/resume")
def curriculum_agent_resume(
    thread_id: str,
    request: CurriculumAgentResumeRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    user_id = getattr(current_user, "id")
    # Verify thread belongs to this user
    parts = thread_id.split("-")
    if len(parts) < 3:
        raise HTTPException(status_code=400, detail="Invalid thread ID")
    try:
        thread_user_id = int(parts[1])
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid thread ID format")

    if thread_user_id != user_id:
        raise HTTPException(status_code=403, detail="Not your thread")

    from backend.main import get_checkpointer
    try:
        checkpointer = get_checkpointer()
    except RuntimeError:
        raise HTTPException(status_code=503, detail="Agent system not initialized")

    from agents.graph import get_compiled_curriculum_graph
    graph = get_compiled_curriculum_graph(checkpointer=checkpointer)

    config: RunnableConfig = {
        "configurable": {"thread_id": thread_id, "db": db},
    }

    # Resume with human input
    resume_value = {
        "decision": request.decision,
        "instruction": request.instruction,
        "response": request.response,
    }

    try:
        from langgraph.types import Command
        result = graph.invoke(Command(resume=resume_value), config=config)

        # Check if still interrupted
        graph_state = graph.get_state(config)
        is_interrupted = bool(graph_state.next)

        if is_interrupted:
            tasks = graph_state.tasks or []
            interrupt_data = None
            for task in tasks:
                if hasattr(task, 'interrupts') and task.interrupts:
                    interrupt_data = task.interrupts[0].value
                    break

            state_values = graph_state.values or {}
            proposed_changes = (
                state_values.get("proposed_changes")
                or (result.get("proposed_changes") if isinstance(result, dict) else None)
                or (interrupt_data.get("proposed_changes") if isinstance(interrupt_data, dict) else None)
            )
            clarification_needed = (
                state_values.get("clarification_needed")
                or (result.get("clarification_needed") if isinstance(result, dict) else None)
                or (interrupt_data.get("question") if isinstance(interrupt_data, dict) and interrupt_data.get("type") == "clarification" else None)
            )
            exec_res = (
                state_values.get("execution_result")
                or (result.get("execution_result") if isinstance(result, dict) else None)
                or ({"summary": interrupt_data.get("summary")} if isinstance(interrupt_data, dict) and interrupt_data.get("summary") else None)
            )

            return {
                "thread_id": thread_id,
                "status": "awaiting_input",
                "interrupt": interrupt_data,
                "proposed_changes": proposed_changes,
                "clarification_needed": clarification_needed,
                "execution_result": exec_res,
            }

        state_values = graph_state.values or {}
        exec_res = (
            (result.get("execution_result") if isinstance(result, dict) else None)
            or state_values.get("execution_result")
        )
        return {
            "thread_id": thread_id,
            "status": "completed",
            "execution_result": exec_res,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Agent resume error: {str(e)}")


@router.get("/curriculum/{curriculum_id}/memories")
def get_curriculum_agent_memories(
    curriculum_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Retrieve recent agent memories for a curriculum."""
    user_id = getattr(current_user, "id")
    verify_curriculum_ownership(db, user_id, curriculum_id)
    from agents.memory import get_memories
    memories = get_memories(db, user_id, curriculum_id, "curriculum", limit=10)
    return {"memories": memories}


@router.get("/curriculum/{thread_id}/status")
def curriculum_agent_status(
    thread_id: str,
    current_user: User = Depends(get_current_user),
):
    user_id = getattr(current_user, "id")
    parts = thread_id.split("-")
    if len(parts) < 3:
        raise HTTPException(status_code=400, detail="Invalid thread ID")
    try:
        thread_user_id = int(parts[1])
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid thread ID format")

    if thread_user_id != user_id:
        raise HTTPException(status_code=403, detail="Not your thread")

    from backend.main import get_checkpointer
    try:
        checkpointer = get_checkpointer()
    except RuntimeError:
        raise HTTPException(status_code=503, detail="Agent system not initialized")

    from agents.graph import get_compiled_curriculum_graph
    graph = get_compiled_curriculum_graph(checkpointer=checkpointer)

    config: RunnableConfig = {"configurable": {"thread_id": thread_id}}

    try:
        graph_state = graph.get_state(config)
        state_values = graph_state.values or {}
        is_interrupted = bool(graph_state.next)

        return {
            "thread_id": thread_id,
            "status": "awaiting_input" if is_interrupted else "completed",
            "proposed_changes": state_values.get("proposed_changes"),
            "execution_result": state_values.get("execution_result"),
        }
    except Exception:
        return {
            "thread_id": thread_id,
            "status": "not_found",
        }


# ============================================================
# ASSESSMENT AGENT ENDPOINTS
# ============================================================

@router.post("/assessment/generate")
def assessment_agent_generate(
    request: AssessmentAgentRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    user_id = getattr(current_user, "id")
    # Verify ownership
    verify_curriculum_ownership(db, user_id, request.curriculum_id)

    # Cap variation count (1-10)
    variation_count = max(1, min(request.variation_count, 10))

    from agents.graph import get_compiled_assessment_graph
    graph = get_compiled_assessment_graph()

    initial_state: AssessmentAgentState = {
        "user_id": user_id,
        "curriculum_id": request.curriculum_id,
        "assessment_type": request.assessment_type,
        "portion": request.portion,
        "total_questions": request.num_questions,
        "difficulty_distribution": request.difficulty_distribution,
        "question_type_distribution": request.question_type_distribution,
        "variation_count": variation_count,
        "syllabus_context": None,
        "blueprint": None,
        "variations": None,
        "batch_id": None,
        "saved_assessment_ids": None,
    }

    config: RunnableConfig = {"configurable": {"db": db}}

    try:
        result = graph.invoke(initial_state, config=config)

        return {
            "batch_id": result.get("batch_id") if isinstance(result, dict) else None,
            "variations": result.get("variations", []) if isinstance(result, dict) else [],
            "saved_assessment_ids": result.get("saved_assessment_ids", []) if isinstance(result, dict) else [],
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Assessment generation error: {str(e)}")


@router.get("/assessment/batches")
def list_assessment_batches(
    curriculum_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """List assessment batches for a curriculum."""
    user_id = getattr(current_user, "id")
    verify_curriculum_ownership(db, user_id, curriculum_id)
    batches = get_assessment_batches(db, user_id, curriculum_id)
    return {"batches": batches}


@router.get("/assessment/batches/{batch_id}")
def get_assessment_batch(
    batch_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get a batch with all its assessment versions."""
    user_id = getattr(current_user, "id")
    result = get_batch_with_assessments(db, batch_id, user_id)
    if not result:
        raise HTTPException(status_code=404, detail="Assessment batch not found")
    return result


@router.delete("/assessment/batches/{batch_id}")
def delete_assessment_batch_endpoint(
    batch_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Delete an assessment batch and all its variations."""
    user_id = getattr(current_user, "id")
    success = delete_assessment_batch(db, batch_id, user_id)
    if not success:
        raise HTTPException(status_code=404, detail="Assessment batch not found or could not be deleted")
    return {"status": "deleted", "batch_id": batch_id}


@router.get("/assessment/{assessment_id}")
def get_single_assessment(
    assessment_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get a single assessment version."""
    user_id = getattr(current_user, "id")
    result = get_assessment(db, assessment_id, user_id)
    if not result:
        raise HTTPException(status_code=404, detail="Assessment not found")
    return result


# ============================================================
# ASSESSMENT EXPORT ENDPOINTS
# ============================================================

@router.get("/assessment/{assessment_id}/export/question-paper")
def export_question_paper_endpoint(
    assessment_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Export clean Question Paper HTML (examination view with MathJax)."""
    from fastapi.responses import HTMLResponse
    from agents.export import render_question_paper_html

    user_id = getattr(current_user, "id")
    assessment = get_assessment(db, assessment_id, user_id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    batch = get_batch_with_assessments(db, assessment["batch_id"], user_id)
    html_content = render_question_paper_html(assessment, batch or {})
    v_num = assessment.get("variation_number", 1)
    return HTMLResponse(
        content=html_content,
        headers={"Content-Disposition": f"inline; filename=Version_{v_num}_Question_Paper.html"}
    )


@router.get("/assessment/{assessment_id}/export/answer-key")
def export_answer_key_endpoint(
    assessment_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Export clean Answer Key & Solution Guide HTML."""
    from fastapi.responses import HTMLResponse
    from agents.export import render_answer_key_html

    user_id = getattr(current_user, "id")
    assessment = get_assessment(db, assessment_id, user_id)
    if not assessment:
        raise HTTPException(status_code=404, detail="Assessment not found")

    batch = get_batch_with_assessments(db, assessment["batch_id"], user_id)
    html_content = render_answer_key_html(assessment, batch or {})
    v_num = assessment.get("variation_number", 1)
    return HTMLResponse(
        content=html_content,
        headers={"Content-Disposition": f"inline; filename=Version_{v_num}_Answer_Key.html"}
    )


@router.get("/assessment/batches/{batch_id}/export/zip")
def export_batch_zip_endpoint(
    batch_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Export all variations in a batch as a ZIP archive."""
    from fastapi.responses import Response
    from agents.export import create_batch_zip

    user_id = getattr(current_user, "id")
    batch = get_batch_with_assessments(db, batch_id, user_id)
    if not batch:
        raise HTTPException(status_code=404, detail="Assessment batch not found")

    zip_bytes = create_batch_zip(batch, batch.get("assessments", []))
    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=Assessment_Batch_{batch_id}_Variations.zip"}
    )

