from fastapi import APIRouter, Depends, HTTPException
from typing import Optional
from sqlalchemy.orm import Session

from backend.auth import get_current_user
from backend.models import User, Curriculum
from backend.database import get_db
from backend.schemas import ChatRequest
from rag.retriever import retrieve_documents
from rag.vector_store import get_vector_store
from rag.embeddings import get_embedding_model
from rag.rag_pipeline import generate_rag_response

router = APIRouter(prefix="/chat", tags=["chat"])

@router.post("")
def chat_endpoint(
    request: ChatRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Verify ownership and get curriculum metadata
    curriculum = db.query(Curriculum).filter(
        Curriculum.id == request.curriculum_id,
        Curriculum.user_id == current_user.id
    ).first()
    
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found or access denied")

    embeddings = get_embedding_model()
    vector_store = get_vector_store(embeddings=embeddings)
    
    # 1. Normal/default retrieval: get top 4 theory chunks
    documents = retrieve_documents(
        vector_store=vector_store,
        query=request.question,
        k=4,
        subject=curriculum.subject,
        grade=curriculum.grade,
        academic_year=curriculum.academic_year,
        curriculum_id=curriculum.id,
        content_types=["theory"]
    )
    
    # 2. Check if the question needs additional context (exercises or answers)
    query_lower = request.question.lower()
    additional_docs = []
    
    if any(keyword in query_lower for keyword in ["exercise", "practice", "question", "quiz", "test", "assignment", "homework"]):
        additional_docs = retrieve_documents(
            vector_store=vector_store,
            query=request.question,
            k=4,
            subject=curriculum.subject,
            grade=curriculum.grade,
            academic_year=curriculum.academic_year,
            curriculum_id=curriculum.id,
            content_types=["exercise"]
        )
    elif any(keyword in query_lower for keyword in ["answer", "solution", "key", "solve"]):
        additional_docs = retrieve_documents(
            vector_store=vector_store,
            query=request.question,
            k=4,
            subject=curriculum.subject,
            grade=curriculum.grade,
            academic_year=curriculum.academic_year,
            curriculum_id=curriculum.id,
            content_types=["answer"]
        )
        
    # 3. Combine up to a maximum of 8 chunks
    documents.extend(additional_docs)
    documents = documents[:8]
    
    response_text = generate_rag_response(documents=documents, question=request.question)
    
    return {"answer": response_text}
