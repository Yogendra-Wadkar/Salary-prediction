from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import Dict, Any

from backend.auth import get_current_user
from backend.models import User, Curriculum
from backend.database import get_db
from backend.schemas import AssessmentGenerateRequest, ReplacementQuestionRequest
from orchestrator import generate_assessment, generate_replacement_question

router = APIRouter(prefix="/assessments", tags=["assessments"])

@router.post("/generate")
def generate_assessment_endpoint(
    request: AssessmentGenerateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Verify ownership and get curriculum metadata
    curriculum = db.query(Curriculum).filter(
        Curriculum.id == request.curriculum_id,
        Curriculum.user_id == current_user.id
    ).first()
    
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found or access denied")

    total_questions = request.num_questions
    
    # 1. Validate Difficulty Distribution
    diff_total = sum(request.difficulty_distribution.values())
    if diff_total != total_questions:
        raise HTTPException(
            status_code=400, 
            detail=f"Difficulty distribution total ({diff_total}) must equal the number of questions ({total_questions})."
        )
        
    # 2. Validate Question Type Distribution
    type_total = sum(request.question_type_distribution.values())
    if type_total != total_questions:
        raise HTTPException(
            status_code=400, 
            detail=f"Question type distribution total ({type_total}) must equal the number of questions ({total_questions})."
        )
        
    config = {
        "assessment_type": request.assessment_type,
        "num_questions": request.num_questions,
        "portion": request.portion,
        "difficulty_distribution": request.difficulty_distribution,
        "question_type_distribution": request.question_type_distribution,
        "subject": curriculum.subject,
        "grade": curriculum.grade,
        "academic_year": curriculum.academic_year
    }
    
    try:
        result = generate_assessment(config, curriculum_id=str(curriculum.id))
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/replace")
def replace_question_endpoint(
    request: ReplacementQuestionRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Verify ownership and get curriculum metadata
    curriculum = db.query(Curriculum).filter(
        Curriculum.id == request.curriculum_id,
        Curriculum.user_id == current_user.id
    ).first()
    
    if not curriculum:
        raise HTTPException(status_code=404, detail="Curriculum not found or access denied")

    try:
        result = generate_replacement_question(
            subject=curriculum.subject,
            grade=curriculum.grade,
            academic_year=curriculum.academic_year,
            assessment_period=request.assessment_period,
            question_type=request.question_type,
            difficulty=request.difficulty,
            question=request.question,
            curriculum_id=str(curriculum.id)
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
