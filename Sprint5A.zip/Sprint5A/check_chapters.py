import chromadb

CHROMA_PATH = "data/chroma"
COLLECTION_NAME = "curriculum_documents"

SUBJECT = "Algebra"
GRADE = "10"
ACADEMIC_YEAR = "2026-2027"

client = chromadb.PersistentClient(path=CHROMA_PATH)
collection = client.get_collection(COLLECTION_NAME)

result = collection.get(
    where={
        "$and": [
            {"subject": SUBJECT},
            {"grade": GRADE},
            {"academic_year": ACADEMIC_YEAR},
        ]
    },
    include=["documents", "metadatas"],
)

documents = result.get("documents", []) or []
metadatas = result.get("metadatas", []) or []

print("=" * 70)
print("ALGEBRA RAW CHROMA CHECK")
print("=" * 70)
print(f"Matching chunks: {len(documents)}")

found = 0

for i, (text, metadata) in enumerate(zip(documents, metadatas)):

    if not text:
        continue

    if "chapter" in text.lower():

        found += 1

        print("\n" + "-" * 70)
        print(f"CHUNK #{i + 1}")
        print(f"Source: {metadata.get('source', '')}")
        print(f"Page: {metadata.get('page', '')}")
        print("-" * 70)
        print(text[:1200])

        if found >= 15:
            break

print("\n" + "=" * 70)
print(f"Chunks containing 'Chapter': {found}")
print("=" * 70)