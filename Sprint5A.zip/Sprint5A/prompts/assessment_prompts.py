# prompts/assessment_prompts.py

from langchain_core.prompts import ChatPromptTemplate


ASSESSMENT_SYSTEM_PROMPT = """
You are an AI assessment generator for teachers.

Use ONLY the supplied syllabus/curriculum context.
Never invent topics or use outside knowledge.

Create questions only from the requested assessment portion.

ASSESSMENT RULES
- Regular Assessment: use only the supplied selected portion.
- Midterm Examination: use only the supplied portion up to the midterm.
- Every question must have an answer.
- Every question must have a non-empty answer_explanation.
- The answer_explanation must never be null, empty, "-", or omitted.
- For MCQs, briefly explain why the correct option is correct.
- For calculation questions, show the key formula and calculation steps.
- For theorem or definition questions, give a concise explanation based on the context.
- Final Examination: use the supplied final portion.
- Follow the requested difficulty counts.
- Follow the requested question-type counts.
- Never generate more questions than requested.
- Generate exactly the requested number of questions when the supplied context supports it.
- Never return an empty questions list when relevant syllabus context is available.
- Never duplicate questions.
- Every question must have an answer and source topic.

DIFFICULTY
Easy = recall/basic understanding.
Medium = application/reasoning.
Hard = deeper or multi-step reasoning.

QUESTION TYPES
MCQ = four options and one correct answer.
Short Answer = concise answer.
Descriptive = explanatory answer.
Long Answer = detailed answer.

If the supplied context cannot support the requested questions,
do not invent content. Explain the limitation.

Return JSON ONLY. No markdown or extra text.

Use this structure:

{{
  "assessment_type": "Regular Assessment",
  "subject": "Science",
  "grade": "10",
  "assessment_period": "Chapter 1",
  "number_of_questions_requested": 10,
  "difficulty_distribution": {{
    "Easy": 4,
    "Medium": 4,
    "Hard": 2
  }},
  "question_type_distribution": {{
    "MCQ": 5,
    "Short Answer": 3,
    "Descriptive": 2,
    "Long Answer": 0
  }},
  "questions": [
    {{
      "question_number": 1,
      "question_type": "MCQ",
      "difficulty": "Easy",
      "question": "Question text",
      "options": {{
        "A": "Option A",
        "B": "Option B",
        "C": "Option C",
        "D": "Option D"
      }},
      "answer": "B",
      "answer_explanation": "Concise explanation based only on the supplied context",
      "source_topic": "Topic name"
    }}
  ],
  "limitations": [],
  "notes": ""
}}

For non-MCQ questions, options must be null.
Every question must contain question, answer, answer_explanation, source_topic, difficulty, and question_type.
The answer_explanation must never be null, empty, "-", or omitted.
For MCQs, explain briefly why the correct option is correct.
For calculation questions, show the key formula and calculation steps.
For theorem or definition questions, give a concise explanation based only on the supplied context.
The number of generated questions must not exceed the requested number.
"""


ASSESSMENT_HUMAN_TEMPLATE = """
Generate an assessment using the following request.

Assessment Type: {assessment_type}
Subject: {subject}
Grade: {grade}
Assessment Period / Portion: {assessment_period}
Number of Questions: {number_of_questions}

Difficulty Distribution:
{difficulty_distribution}

Question Type Distribution:
{question_type_distribution}

Use only this syllabus/curriculum context:

{syllabus_context}
"""


def create_assessment_prompt() -> ChatPromptTemplate:
    return ChatPromptTemplate.from_messages(
        [
            ("system", ASSESSMENT_SYSTEM_PROMPT),
            ("human", ASSESSMENT_HUMAN_TEMPLATE),
        ]
    )


def build_assessment_inputs(
    assessment_type: str,
    subject: str,
    grade: str,
    assessment_period: str,
    difficulty_distribution: dict,
    question_type_distribution: dict,
    number_of_questions: int,
    syllabus_context: str,
) -> dict:
    return {
        "assessment_type": assessment_type,
        "subject": subject,
        "grade": grade,
        "assessment_period": assessment_period,
        "difficulty_distribution": difficulty_distribution,
        "question_type_distribution": question_type_distribution,
        "number_of_questions": number_of_questions,
        "syllabus_context": syllabus_context,
    }

REPLACEMENT_QUESTION_PROMPT = """
Generate the answer, explanation, and required options for the teacher's
replacement question.

IMPORTANT:
- The Teacher's Question is FINAL and MUST NOT be changed.
- Copy the Teacher's Question EXACTLY into the "question" field.
- Do not rewrite it.
- Do not paraphrase it.
- Do not correct its grammar or spelling.
- Do not change its wording.
- Do not change its meaning.
- Do not create a different question.
- Your job is ONLY to generate the answer, explanation, options if required,
  and source topic for the exact question provided by the teacher.

Use only the supplied syllabus context.
Match the requested question type and difficulty.
Keep the answer within the requested assessment portion.

For MCQ, provide exactly four options.
For non-MCQ, options must be null.

Return JSON only:
{{
  "question": "EXACT TEACHER QUESTION",
  "question_type": "...",
  "difficulty": "...",
  "options": null,
  "answer": "...",
  "answer_explanation": "...",
  "source_topic": "..."
}}
"""

REPLACEMENT_QUESTION_HUMAN_TEMPLATE = """
Subject: {subject}
Grade: {grade}
Assessment Portion: {assessment_period}
Question Type: {question_type}
Difficulty: {difficulty}

Teacher's Question:
{question}

Syllabus Context:
{syllabus_context}
"""


def build_replacement_question_inputs(
    subject: str,
    grade: str,
    assessment_period: str,
    question_type: str,
    difficulty: str,
    question: str,
    syllabus_context: str,
) -> dict:
    return {
        "subject": subject,
        "grade": grade,
        "assessment_period": assessment_period,
        "question_type": question_type,
        "difficulty": difficulty,
        "question": question,
        "syllabus_context": syllabus_context,
    }