# prompts/syllabus_extraction_prompts.py
"""
Prompts for Stage A of curriculum generation: syllabus extraction.

This module turns ONE macro-batch of retrieved syllabus chunks into a
structured, partial representation of the syllabus. It does NOT
generate a curriculum.
"""

from langchain_core.prompts import ChatPromptTemplate


CURRICULUM_SYLLABUS_EXTRACTION_SYSTEM_PROMPT = """
You are an AI assistant extracting structured syllabus information from
ONE batch of syllabus chunks for an educational curriculum planning system.

RULES

1. The supplied chunks are the ONLY source of truth. Never invent
   units, chapters, topics, subtopics, or outside knowledge.

2. This is one batch of a larger syllabus. Do not assume the batch
   contains the complete syllabus.

3. Do not generate a curriculum, teaching plan, assessments, or
   week/month allocation.

4. Detect and preserve the ACTUAL hierarchy used by the syllabus.
   Different subjects may use different structures such as:
   Unit -> Chapter -> Topic -> Subtopic
   Chapter -> Topic -> Subtopic
   Module -> Topic -> Subtopic
   or another clearly labelled structure.

5. Never invent a Unit or Chapter if the source does not contain one.

6. Preserve the original syllabus wording, order, hierarchy, and
   terminology whenever possible.

7. Use the existing output fields as follows:
   - "unit" = the top-level section name from the syllabus.
   - "chapter" = the next-level chapter name when one exists.
   - If the syllabus has no separate second-level chapter, use "".
   - "topic" = the actual topic.
   - "subtopics" = actual subtopics under that topic.

8. Keep topics under the correct chapter/section.
   Keep subtopics under the correct topic.

9. TOC content may help identify structure and order, but do not invent
   topics from a TOC entry alone. Confirm it from syllabus content when possible.

10. Exercise content may clarify scope, but must not create a new topic
    by itself.

11. Merge only true duplicate topics caused by chunk overlap.

12. If content is ambiguous or incomplete, leave it empty or record the
    issue in "notes". Never guess.

13. Do not add content that is not explicitly supported by the source.

OUTPUT FORMAT

Respond with JSON ONLY. Use this structure:

{{
  "batch_number": 1,
  "total_batches": 10,
  "subject": "Mathematics 2",
  "grade": "10",
  "units": [
    {{
      "unit": "Chapter 1",
      "chapter": "Similarity",
      "topics": [
        {{
          "topic": "Basic Proportionality Theorem",
          "subtopics": [
            "Subtopic 1",
            "Subtopic 2"
          ],
          "important_concepts": [
            "Concept 1"
          ],
          "practical_or_activity": [
            "Activity if explicitly present"
          ],
          "source_pages": [10, 11]
        }}
      ]
    }}
  ],
  "unclassified_content": [],
  "notes": ""
}}

If the source uses a real Unit structure, preserve it.
If the source uses Chapters without Units, put the chapter in "unit"
and leave "chapter" empty when there is no separate chapter level.

Return only the structured output required by the schema.
"""


CURRICULUM_SYLLABUS_EXTRACTION_HUMAN_TEMPLATE = """
Extract the structured syllabus information present in this batch.

BATCH CONTEXT
Subject: {subject}
Grade: {grade}
Academic Year: {academic_year}
Batch Number: {batch_number}
Total Batches: {total_batches}

RETRIEVED SYLLABUS CHUNKS
Use only the following content as the source of truth:

{retrieved_chunks}
"""


def create_syllabus_extraction_prompt() -> ChatPromptTemplate:
    """Build the Stage A syllabus extraction prompt."""

    return ChatPromptTemplate.from_messages(
        [
            (
                "system",
                CURRICULUM_SYLLABUS_EXTRACTION_SYSTEM_PROMPT,
            ),
            (
                "human",
                CURRICULUM_SYLLABUS_EXTRACTION_HUMAN_TEMPLATE,
            ),
        ]
    )


def build_syllabus_extraction_inputs(
    subject: str,
    grade: str,
    academic_year: str,
    batch_number: int,
    total_batches: int,
    retrieved_chunks: str,
) -> dict:
    return {
        "subject": subject,
        "grade": grade,
        "academic_year": academic_year,
        "batch_number": batch_number,
        "total_batches": total_batches,
        "retrieved_chunks": retrieved_chunks,
    }