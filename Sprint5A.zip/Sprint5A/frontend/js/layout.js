/* ============================================================
   TeacherOS — Shared Sidebar Layout
   Single source of truth for navigation across all pages.
   ============================================================ */

/**
 * Call initLayout() on every authenticated page.
 * It injects the sidebar, loads curricula for the dropdown,
 * highlights the active nav item, and wires up logout.
 *
 * @param {string} activePage  - one of: 'home', 'dashboard',
 *   'my-curricula', 'curriculum-builder', 'curriculum-view',
 *   'chatbot', 'assessment'
 */
async function initLayout(activePage) {
    // 1. Build sidebar HTML
    const sidebar = document.createElement('div');
    sidebar.className = 'sidebar';
    sidebar.id = 'app-sidebar';
    sidebar.innerHTML = `
        <div class="sidebar-brand">
            <h1>TeacherOS</h1>
            <span>AI-Powered Assistant</span>
        </div>

        <div class="sidebar-curriculum">
            <label>Active Curriculum</label>
            <select id="global-curriculum-select">
                <option value="" disabled selected>Loading...</option>
            </select>
        </div>

        <nav class="sidebar-nav">
            <a href="home.html" data-page="home">
                <span class="nav-icon">🏠</span> Home
            </a>
            <a href="dashboard.html" data-page="dashboard">
                <span class="nav-icon">📊</span> Dashboard
            </a>

            <div class="sidebar-section-label">Curriculum</div>
            <a href="my-curricula.html" data-page="my-curricula">
                <span class="nav-icon">📚</span> My Curriculum
            </a>
            <a href="curriculum-builder.html?mode=new" data-page="curriculum-builder">
                <span class="nav-icon">🛠️</span> Curriculum Builder
            </a>

            <div class="sidebar-section-label">AI Tools</div>
            <a href="chatbot.html" data-page="chatbot">
                <span class="nav-icon">💬</span> AI Assistant
            </a>
            <a href="curriculum-agent.html" data-page="curriculum-agent">
                <span class="nav-icon">🤖</span> Curriculum Agent
            </a>
            <a href="assessment-agent.html" data-page="assessment-agent">
                <span class="nav-icon">📝</span> Assessment Agent
            </a>
        </nav>

        <div class="sidebar-footer">
            <a href="#" id="sidebar-logout">
                <span class="nav-icon">🚪</span> Logout
            </a>
        </div>
    `;

    // 2. Insert sidebar + wrap existing body content
    const mainContent = document.createElement('div');
    mainContent.className = 'main-content';
    mainContent.id = 'main-content';

    // Move all body children into main-content
    while (document.body.firstChild) {
        mainContent.appendChild(document.body.firstChild);
    }

    const layout = document.createElement('div');
    layout.className = 'app-layout';
    layout.appendChild(sidebar);
    layout.appendChild(mainContent);
    document.body.appendChild(layout);

    // 3. Highlight active nav item
    const navLinks = sidebar.querySelectorAll('.sidebar-nav a[data-page]');
    navLinks.forEach(link => {
        if (link.dataset.page === activePage) {
            link.classList.add('active');
        }
    });

    // 4. Logout handler
    document.getElementById('sidebar-logout').addEventListener('click', (e) => {
        e.preventDefault();
        logout();
    });

    // 5. Load curricula for the global selector
    await loadGlobalCurricula();
}


/**
 * Loads all user curricula and populates the global
 * Active Curriculum dropdown. Restores the previously
 * selected curriculum from localStorage.
 */
async function loadGlobalCurricula() {
    const select = document.getElementById('global-curriculum-select');
    if (!select) return;

    try {
        const curricula = await apiCall('/curriculums');

        if (curricula.length === 0) {
            select.innerHTML = '<option value="" disabled selected>No curricula yet</option>';
            return;
        }

        select.innerHTML = '';
        const storedId = getActiveCurriculumId();
        let foundStored = false;

        curricula.forEach(c => {
            const opt = document.createElement('option');
            opt.value = c.id;
            opt.textContent = `${c.subject} - Grade ${c.grade}`;
            if (String(c.id) === storedId) {
                opt.selected = true;
                foundStored = true;
            }
            select.appendChild(opt);
        });

        // If no stored curriculum, select the first one
        if (!foundStored && curricula.length > 0) {
            select.value = curricula[0].id;
            setActiveCurriculumId(String(curricula[0].id));
        }

        // Listen for changes
        select.addEventListener('change', () => {
            setActiveCurriculumId(select.value);
            // Dispatch custom event so pages can react
            window.dispatchEvent(new CustomEvent('activeCurriculumChanged', {
                detail: { curriculumId: select.value }
            }));
        });

    } catch (err) {
        select.innerHTML = '<option value="" disabled selected>Error loading</option>';
        console.error('Failed to load curricula for sidebar:', err);
    }
}


/**
 * Helper to get the currently selected global curriculum ID.
 * Returns null if none is selected.
 */
function getGlobalCurriculumId() {
    const select = document.getElementById('global-curriculum-select');
    return select ? select.value || null : getActiveCurriculumId();
}


/**
 * Returns the status CSS class for a given status string.
 */
function getStatusClass(status) {
    switch (status) {
        case 'In Progress':     return 'sel-progress';
        case 'Completed':       return 'sel-completed';
        case 'Not Completed':   return 'sel-notcompleted';
        default:                return 'sel-pending';
    }
}

/**
 * Returns the badge CSS class for a given status string.
 */
function getStatusBadgeClass(status) {
    switch (status) {
        case 'In Progress':     return 'status-progress';
        case 'Completed':       return 'status-completed';
        case 'Not Completed':   return 'status-notcompleted';
        default:                return 'status-pending';
    }
}
