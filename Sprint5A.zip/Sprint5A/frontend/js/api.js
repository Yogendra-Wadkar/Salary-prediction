/* ============================================================
   TeacherOS — Shared API Utility
   ============================================================ */

const API_URL = window.location.origin;

/* ---------- Token Management ---------- */

function getToken() {
    return sessionStorage.getItem("access_token");
}

function setToken(token) {
    sessionStorage.setItem("access_token", token);
}

function removeToken() {
    sessionStorage.removeItem("access_token");
    localStorage.removeItem("access_token"); // Clear any old stale tokens
}

/* ---------- Active Curriculum ---------- */

function getActiveCurriculumId() {
    return localStorage.getItem("activeCurriculumId");
}

function setActiveCurriculumId(id) {
    localStorage.setItem("activeCurriculumId", id);
}

function removeActiveCurriculumId() {
    localStorage.removeItem("activeCurriculumId");
}

/* ---------- Auth Headers ---------- */

function getAuthHeaders() {
    const token = getToken();
    return token ? { "Authorization": `Bearer ${token}` } : {};
}

/* ---------- API Call Helper ---------- */

async function apiCall(endpoint, options = {}) {
    const url = `${API_URL}${endpoint}`;
    const headers = {
        "Content-Type": "application/json",
        ...getAuthHeaders(),
        ...(options.headers || {})
    };

    // Let browser set multipart boundaries for FormData
    if (options.body instanceof FormData) {
        delete headers["Content-Type"];
    }

    const response = await fetch(url, { ...options, headers });

    if (response.status === 401) {
        removeToken();
        removeActiveCurriculumId();
        window.location.href = "/index.html";
        throw new Error("Unauthorized");
    }

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
        throw new Error(data.detail || "An error occurred");
    }

    return data;
}

/* ---------- Logout Helper ---------- */

function logout() {
    removeToken();
    removeActiveCurriculumId();
    window.location.href = "/index.html";
}

/* ---------- Auth Guard ---------- */

if (!getToken() && !window.location.pathname.endsWith("index.html") && window.location.pathname !== "/") {
    window.location.href = "/index.html";
}

