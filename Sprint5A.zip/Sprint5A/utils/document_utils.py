from pathlib import Path
from typing import List

from langchain_core.documents import Document
from langchain_community.document_loaders import PyMuPDFLoader
from docx import Document as DocxDocument


SUPPORTED_EXTENSIONS = {".pdf", ".docx"}


def load_pdf(file_path: str) -> List[Document]:
    """Load a PDF using LangChain's PyMuPDFLoader."""
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    loader = PyMuPDFLoader(str(path))
    return loader.load()


def load_docx(file_path: str) -> List[Document]:
    """Load text from a DOCX file and return LangChain Documents."""
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    docx_file = DocxDocument(str(path))

    text_parts = [
        paragraph.text.strip()
        for paragraph in docx_file.paragraphs
        if paragraph.text.strip()
    ]

    text = "\n".join(text_parts)

    return [
        Document(
            page_content=text,
            metadata={
                "source": str(path),
                "file_type": "docx"
            }
        )
    ]


def load_document(file_path: str) -> List[Document]:
    """Load a supported PDF or DOCX document."""
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    extension = path.suffix.lower()

    if extension == ".pdf":
        return load_pdf(file_path)

    if extension == ".docx":
        return load_docx(file_path)

    raise ValueError(
        f"Unsupported file type: {extension}. "
        "Only PDF and DOCX files are supported."
    )